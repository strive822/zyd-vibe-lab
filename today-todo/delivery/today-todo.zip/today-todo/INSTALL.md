# 安装与运行

这份文档写给执行安装的 Agent，也写给本人。三步是分开的：**下载**（拿到文件）、**安装**（放到新目录并核验）、**运行**（启动服务并验证页面）。

本项目零依赖，没有 `npm install`，也没有构建步骤。所谓“安装”就是把文件放到一个干净目录并核对校验值。

## 运行要求

| 项 | 要求 |
|---|---|
| 系统 | Windows 10/11（服务本身是跨平台的，`start.bat` / `stop.bat` 只在 Windows 可用） |
| 运行时 | Node.js 18 或更新（在 Node 24 上验证）。`node -v` 能输出版本即可 |
| 网络 | 电脑与手机在同一局域网；不需要外网 |
| 磁盘 | 小于 1 MB（不含 `data/todos.json`） |
| 端口 | 3000，被占用时自动试 3001–3005 |

## 一、下载

### 方式 A：克隆仓库（推荐）

```bash
git clone https://github.com/strive822/zyd-vibe-lab.git
```

这是多项目仓库，本项目只占 `today-todo/` 一个目录。不要解压或复制到已有项目的目录里。

### 方式 B：独立交付包

从以下固定项目入口下载 ZIP、校验和与逐文件清单；先比较 ZIP SHA-256、检查归档路径，再解压到一个**新目录**：

```text
https://raw.githubusercontent.com/strive822/zyd-vibe-lab/main/today-todo/delivery/today-todo.zip
https://raw.githubusercontent.com/strive822/zyd-vibe-lab/main/today-todo/delivery/SHA256SUMS.txt
https://raw.githubusercontent.com/strive822/zyd-vibe-lab/main/today-todo/delivery/FILES.json
```

```bash
mkdir zyd-today-todo && tar -xf today-todo.zip -C zyd-today-todo
```

包内已含源码、脚本、文档和图标，不依赖仓库里的其他项目。

## 二、安装与核验

1. **放到新目录**。若目标目录已存在同名文件，先停下确认，不要覆盖。
2. **核对压缩包**（方式 B）：

   ```bash
   sha256sum today-todo.zip
   ```

   Windows 可用：

   ```bat
   certutil -hashfile today-todo.zip SHA256
   ```

   结果必须与 `delivery/SHA256SUMS.txt` 中的值一致。
3. **逐文件核对**（可选，严格模式）：`delivery/FILES.json` 记录了包内每个相对路径的 SHA-256，可逐个比对。
4. **不要**把自带的 `data/` 复制进来 —— 仓库不含任何清单数据，首次运行会自动创建。

## 三、运行

```bash
node server.js
```

或双击 `start.bat`（会设置 UTF-8 控制台，并在监听成功后自动打开默认浏览器）。

启动成功的标志：终端出现分隔线、`http://localhost:3000`、以及一行 `[推荐] http://<局域网IP>:3000`。

- 端口被占用时自动往后找，终端打印的是**实际**端口
- 已有实例在跑时不会启动第二个，只打开它的地址（避免两个进程写同一份数据）

## 四、手机访问

1. 手机连**同一个 WiFi**
2. 浏览器输入终端里 `[推荐]` 那行地址
3. 首次运行 Windows 可能询问是否允许 Node.js 访问网络，选“允许”

打不开时按顺序排查：

| 现象 | 处理 |
|---|---|
| 手机超时，电脑本机能开 | 防火墙拦了入站。可在管理员终端执行：`netsh advfirewall firewall add rule name="TodayTodo 3000" dir=in action=allow protocol=TCP localport=3000`（删除规则把 `add` 换成 `delete`） |
| 换了网络就好了 | 原网络开了客户端隔离（校园网常见），改用手机热点 |
| 打开是旧内容 | 端口不对，看终端最新打印的地址 |

## 五、验证（要能证明结果，不是“启动了”）

| 检查 | 命令 / 操作 | 期望 |
|---|---|---|
| 接口活着 | `curl -s http://127.0.0.1:3000/api/health` | 返回 `{"ok":true,...}` |
| 页面可访问 | 浏览器打开 `http://localhost:3000` | 看到标题「今日待办」与清单 |
| 写入链路 | 点「+」→ 写一条 → 点「添加」 | 条目出现在顶部，计数 +1 |
| 勾选 | 点复选框 | 变黑底黄勾、文字划线、计数 −1 |
| 编辑 | 点铅笔 → 改字 → Enter | 文本更新，完成状态不变 |
| 删除 + 撤销 | 点红色 ×，再点「撤销」 | 条目消失后恢复 |
| 持久化 | 关掉服务重新启动 | 清单仍在 |
| 自动化 | `node --test test/api.test.js` | 16 项全部通过 |
| 对比度 | `node tools/contrast.js` | 13 组全部达到 4.5:1 / 3:1 |

页面可访问 ≠ 数据可写，也 ≠ 手机能连上；这三件事要分开确认。

## 六、停止

- 关掉那个终端窗口，或按 `Ctrl+C`
- 找不到窗口时双击 `stop.bat`（扫描 3000–3005 并结束对应进程）
- 只关浏览器页面**不会**停止服务 —— 手机还在用同一份数据

## 七、数据与备份

- 唯一数据源：`data/todos.json`
- 备份：复制整个 `data/` 目录
- 恢复：停服务 → 放回文件 → 启动
- 不要在两个进程里同时使用同一个数据文件

## 八、权限边界

Agent 执行本项目的安装与运行时，只应做以下事情：

- 在用户指定或新建的目录内读写文件
- 用 `node` 运行本项目脚本，监听 3000–3005
- 运行只读的测试与检查脚本

不应做：

- 修改 Windows 防火墙、安装系统服务、写注册表、加入开机自启（需要用户单独授权）
- 全局安装任何包（本项目零依赖，`npm install` 也不需要）
- 上传、外发或收集 `data/todos.json` 的内容
- 覆盖用户已有的数据文件或另一个项目的目录
- 声称“手机端可用”而未实际用手机打开过

## 九、卸载

先停止服务并备份仍需保留的 data/todos.json，再删除项目目录，服务不写注册表、不装服务、不留后台进程。若建过桌面快捷方式，把快捷方式一并删除。
