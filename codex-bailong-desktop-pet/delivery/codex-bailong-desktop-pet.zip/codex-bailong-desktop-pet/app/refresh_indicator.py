"""Single-arc refresh action; repaint only its small vector while visible."""
import math
import time
from PySide6.QtCore import Qt,QPointF,QRectF,QTimer
from PySide6.QtGui import QColor,QIcon,QPainter,QPainterPath,QPen
from PySide6.QtWidgets import QToolButton,QStyle,QStyleOptionToolButton

REFRESH_SECONDS=2.0
BRAKE_SECONDS=.28
FEEDBACK_SECONDS=1.1
RESTORE_SECONDS=.2


class RefreshButton(QToolButton):
    def __init__(self,parent=None,clock=None):
        super().__init__(parent)
        self.clock=clock or time.monotonic
        self.busy=False;self.result=None;self.started=0.;self.finished_at=None
        self.finish_angle=0.;self.finish_scale=1.
        self._motion_offset=0.;self._hidden_at=self.clock();self._motion_holds={'hidden'}
        self.timer=QTimer(self);self.timer.setInterval(33);self.timer.timeout.connect(self._tick)

    def _motion_now(self):
        return (self._hidden_at if self._hidden_at is not None else self.clock())-self._motion_offset

    def set_busy(self,value):
        value=bool(value)
        if value==self.busy:return
        self.busy=value;self.result=None;self.finished_at=None
        if value:self.started=self._motion_now()
        self.setEnabled(not value);self._sync();self.update()

    def finish(self,success=True):
        angle,scale,_,_=self.pose()
        self.finish_angle=angle;self.finish_scale=scale
        self.busy=False;self.result=bool(success);self.finished_at=self._motion_now()
        self.setEnabled(True);self._sync();self.update()

    def pose(self):
        now=self._motion_now()
        if self.busy:
            t=max(0.,now-self.started)
            return (360*t/REFRESH_SECONDS, .975+.025*math.cos(math.tau*t/REFRESH_SECONDS),1.,0.)
        if self.finished_at is None:return (0.,1.,1.,0.)
        t=max(0.,now-self.finished_at)
        brake=min(t,BRAKE_SECONDS)
        angle=self.finish_angle+360/REFRESH_SECONDS*(brake-brake*brake/(2*BRAKE_SECONDS))
        mix=min(1.,t/BRAKE_SECONDS);mix=mix*mix*(3-2*mix)
        scale=self.finish_scale+(1-self.finish_scale)*mix
        if t<BRAKE_SECONDS:return (angle,scale,1-mix,mix)
        if t<BRAKE_SECONDS+FEEDBACK_SECONDS:return (angle,1.,0.,1.)
        mix=min(1.,(t-BRAKE_SECONDS-FEEDBACK_SECONDS)/RESTORE_SECONDS)
        mix=mix*mix*(3-2*mix)
        return (0.,1.,mix,1-mix)

    def _sync(self):
        if self.finished_at is not None and self._motion_now()-self.finished_at>=BRAKE_SECONDS+FEEDBACK_SECONDS+RESTORE_SECONDS:
            self.finished_at=None;self.result=None
        running=self.isVisible() and not self._motion_holds and (self.busy or self.finished_at is not None)
        if running and not self.timer.isActive():self.timer.start()
        elif not running:self.timer.stop()

    def _tick(self):
        self._sync()
        if self.updatesEnabled():self.update()

    def freeze_motion(self,reason='surface'):
        if not self._motion_holds:self._hidden_at=self.clock()
        self._motion_holds.add(reason);self.timer.stop()

    def resume_motion(self,reason='surface'):
        self._motion_holds.discard(reason)
        if not self._motion_holds and self._hidden_at is not None:
            self._motion_offset+=self.clock()-self._hidden_at;self._hidden_at=None
        self._sync()

    def showEvent(self,event):
        super().showEvent(event);self.resume_motion('hidden')

    def hideEvent(self,event):
        self.freeze_motion('hidden');super().hideEvent(event)

    def paintEvent(self,event):
        # Keep native hover/press/focus behavior without painting the static QIcon.
        option=QStyleOptionToolButton();self.initStyleOption(option);option.icon=QIcon()
        p=QPainter(self);self.style().drawComplexControl(QStyle.ComplexControl.CC_ToolButton,option,p,self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        size=min(18,self.iconSize().width(),self.width()-6,self.height()-6)
        p.translate(self.width()/2,self.height()/2)
        if self.isDown():p.scale(.92,.92)
        p.scale(size/18,size/18)
        angle,scale,arrow_alpha,result_alpha=self.pose()
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor('#927aaf'),1.65,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
        if arrow_alpha>.001:
            p.save();p.setOpacity(arrow_alpha);p.rotate(angle);p.scale(scale,scale);p.translate(-9,-9)
            path=QPainterPath(QPointF(15,9))
            path.cubicTo(15,12.3,12.3,15,9,15);path.cubicTo(5.7,15,3,12.3,3,9)
            path.cubicTo(3,5.7,5.7,3,9,3);path.cubicTo(11.2,3,13.2,4.1,14.4,5.9)
            p.drawPath(path)
            head=QPainterPath(QPointF(14.4,2.5));head.lineTo(14.4,6);head.lineTo(10.9,6);p.drawPath(head)
            p.restore()
        if result_alpha>.001:
            p.setOpacity(result_alpha);p.translate(-9,-9)
            if self.result:
                path=QPainterPath(QPointF(4,9));path.lineTo(7.4,12.3);path.lineTo(14,5.7);p.drawPath(path)
            else:
                p.setPen(QPen(QColor('#915e74'),1.65,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
                p.drawLine(QPointF(9,4),QPointF(9,10))
                p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#915e74'));p.drawEllipse(QRectF(8.1,12.5,1.8,1.8))
