"""Directly labelled quota bars, independent reset times and daily token total."""
import math,time
from PySide6.QtCore import Qt,QRectF,QSize,QPoint,Signal,QTimer,QVariantAnimation,QEasingCurve,QAbstractAnimation
from PySide6.QtGui import QPainter,QPen,QColor,QFontMetrics,QPixmap
from PySide6.QtWidgets import QWidget,QToolButton
from compact_bubble import font,INK,MUTED
from quota_summary_data import quota_items,today_tokens
from reset_watch import local_time
from ui_theme import QUOTA_WEEK,QUOTA_FIVE,QUOTA_LOW

HEIGHT=102

def quota_color(item):
    if item['name']=='一周':
        remaining=item.get('remaining')
        if remaining is None:return QColor('#9b93a4')
        # Colour follows actual quota, never the 0-to-value entry animation.
        stops=((0,'#ac6e85'),(15,'#ac6e85'),(35,'#b18e62'),(65,'#9b86b0'),(100,QUOTA_WEEK))
        for (start,left),(end,right) in zip(stops,stops[1:]):
            if remaining<=end:
                fraction=max(0.,min(1.,(remaining-start)/(end-start)))
                a,b=QColor(left),QColor(right)
                return QColor(*(round(x+(y-x)*fraction) for x,y in zip(a.getRgb()[:3],b.getRgb()[:3])))
        return QColor(QUOTA_WEEK)
    return QColor(QUOTA_LOW if item['low'] else QUOTA_WEEK if item['name']=='一周' else QUOTA_FIVE)

class QuotaSummary(QWidget):
    expand=Signal()
    anomalyRequested=Signal()
    resetDue=Signal(float)
    def __init__(self,windows,caption='',parent=None,progress_cache=None,clock=None,anomaly=None):
        super().__init__(parent);self.setObjectName('quota_summary');self.setFixedHeight(HEIGHT);self.setMinimumWidth(106)
        self.windows=[dict(w) for w in windows];self.caption=caption;self.clock=clock or time.time
        self.items=quota_items(self.windows,self.clock());self.cache=progress_cache if progress_cache is not None else {}
        self.anomaly=anomaly;self.week_index=next((i for i,w in enumerate(self.items) if w['name']=='一周'),None)
        self.alert_height=0
        self.alert_badge=QToolButton(self);self.alert_badge.setObjectName('week_quota_alert')
        badge_text=f"{anomaly.get('change',0):+.0f}%" if anomaly else ''
        self.alert_badge.setText(badge_text);self.alert_badge.setFont(font(11,True))
        self.alert_badge.setFixedSize(max(38,QFontMetrics(self.alert_badge.font()).horizontalAdvance(badge_text)+10),18)
        self.alert_badge.setCursor(Qt.CursorShape.PointingHandCursor)
        increase=bool(anomaly and anomaly.get('change',0)>0)
        self.alert_badge.setAccessibleName('周额度推测总量'+('上涨' if increase else '下降')+'提醒，查看额度对比')
        colors=('#e6f6eb','#218358','#d6f1df','#c4e8d1') if increase else ('#ffebec','#ce2c31','#ffdbdc','#ffcdce')
        self.alert_badge.setStyleSheet('QToolButton{background:'+colors[0]+';color:'+colors[1]+';border:0;border-radius:7px;padding:0;}QToolButton:hover{background:'+colors[2]+';}QToolButton:pressed{background:'+colors[3]+';}')
        self.alert_badge.clicked.connect(self.anomalyRequested.emit)
        self.alert_badge.setVisible(bool(anomaly and self.week_index is not None))
        if anomaly:self.alert_badge.setAccessibleDescription(anomaly['description'])
        self.active=None;self.pressed=False;self.values={};self.starts={};self.targets={};self._due_sent=set()
        self._static_key=None;self._revision=0;self.layer_builds=0
        self.setMouseTracking(True);self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.animation=QVariantAnimation(self);self.animation.setDuration(420);self.animation.setStartValue(0.);self.animation.setEndValue(1.)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic);self.animation.valueChanged.connect(self.animate)
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.timeout.connect(self._refresh_time)
        for item in self.items:
            key=item['id'];target=item['progress'] or 0.
            self.targets[key]=target;self.starts[key]=self.cache.get(key,target) if item['progress'] is not None else 0.
            self.values[key]=self.starts[key]
        self._accessible();self.animate(0.)
    def sizeHint(self):return QSize(121,HEIGHT+self.alert_height)
    def _accessible(self):
        text='\n'.join(i['description'] for i in self.items)+'\n'+self.caption
        if self.anomaly and self.week_index is not None:text+='\n'+self.anomaly['description']
        self.setAccessibleName('账户剩余额度；点击查看额度详情');self.setAccessibleDescription(text)
    def row_rect(self,index):
        shift=self.row_shift(index)
        return QRectF(3,3+shift,self.width()-6,96) if len(self.items)==1 else QRectF(3,3+index*48+shift,self.width()-6,47)
    def row_shift(self,index):return 0
    def value_rect(self,index):
        single=len(self.items)==1;y=(0 if single else index*48)+self.row_shift(index)
        rect=QRectF(10,26+y,self.width()-20,34) if single else QRectF(58,y+4,self.width()-68,24)
        if not single and index==self.week_index and self.anomaly:rect=QRectF(28,y+4,self.alert_rect().left()-32,24)
        return rect
    def alert_rect(self):return QRectF(self.width()-self.alert_badge.width()-7,(0 if len(self.items)==1 else (self.week_index or 0)*48)+6,self.alert_badge.width(),18)
    def resizeEvent(self,event):
        self.alert_badge.move(self.alert_rect().topLeft().toPoint())
        super().resizeEvent(event)
    def _schedule(self):
        if not self.isVisible():return
        now=self.clock();future=[i['reset_at']-now for i in self.items if i['reset_at'] and i['reset_at']>now]
        # Minute countdowns need one wake on each next minute/reset boundary.
        seconds=min([60-now%60]+future)
        self.timer.start(max(30,math.ceil(seconds*1000)))
    def _refresh_time(self,request=True):
        fresh=quota_items(self.windows,self.clock())
        changed=fresh!=self.items;self.items=fresh
        for item in fresh:
            if item['expired']:
                self.targets[item['id']]=self.starts[item['id']]=self.values[item['id']]=0.
                self.cache[item['id']]=0.
        if changed:self._revision+=1;self._accessible();self.update()
        # One query covers all newly expired windows, including a second
        # deadline reached while the first window still has stale data.
        pending={i['reset_at'] for i in fresh if i['expired']}-self._due_sent
        if request and pending:
            self._due_sent.update(pending);self.resetDue.emit(max(pending))
        self._schedule()
    def animate(self,fraction):
        for key,target in self.targets.items():self.values[key]=self.starts[key]+(target-self.starts[key])*fraction;self.cache[key]=self.values[key]
        region=self.reveal_region()
        if self.visibleRegion().intersects(region):self.update(region)
    def begin_reveal(self):
        self.ensure_static();self.animation.stop();self.starts={k:0. for k in self.targets};self.animate(0.)
    def start_reveal(self):
        if self.animation.state()!=QAbstractAnimation.State.Running and self.isVisible() and any(abs(self.values[k]-v)>.0005 for k,v in self.targets.items()):self.animation.start()
    def showEvent(self,event):
        super().showEvent(event)
        # Refresh synchronously before the first paint after being hidden.
        # Queue the query: emitting here could re-enter the parent's redraw.
        self._refresh_time(request=False)
        transition=getattr(self.window(),'size_transition',None)
        if not transition or not (transition.running or transition.preparing):self.start_reveal()
        if any(i['expired'] for i in self.items):QTimer.singleShot(0,self,self._refresh_time)
    def hideEvent(self,event):
        self.timer.stop();self.animation.stop();self.active=None;self.pressed=False;super().hideEvent(event)
    def mouseMoveEvent(self,event):
        index=next((i for i in range(len(self.items)) if self.row_rect(i).contains(event.position())),None)
        if index!=self.active:self.active=index;self.update()
        super().mouseMoveEvent(event)
    def leaveEvent(self,event):self.active=None;self.update();super().leaveEvent(event)
    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:self.pressed=True;self.update();event.accept()
    def mouseReleaseEvent(self,event):
        clicked=self.pressed and event.button()==Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint())
        self.pressed=False;self.update()
        if clicked:self.expand.emit()
    def _track(self,p,rect,item):
        color=quota_color(item);track=QColor(color);track.setAlpha(33)
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(track);p.drawRoundedRect(rect,rect.height()/2,rect.height()/2)
        if item['progress'] is None:
            p.setPen(QPen(QColor('#8e819c'),1.3));p.drawLine(rect.center().toPoint()+QPoint(-3,0),rect.center().toPoint()+QPoint(3,0))
    def track_rect(self,index):
        return QRectF(10,(65 if len(self.items)==1 else index*48+29)+self.row_shift(index),self.width()-20,8 if len(self.items)==1 else 6)
    def reveal_region(self):
        rect=QRectF()
        for i in range(len(self.items)):rect=rect.united(self.track_rect(i))
        return rect.adjusted(-1,-1,1,1).toAlignedRect()
    def ensure_static(self):
        ratio=self.devicePixelRatioF();key=(self.width(),self.height(),ratio,self._revision,self.active,self.pressed)
        if self._static_key==key:return
        image=QPixmap(max(1,int(self.width()*ratio+.5)),max(1,int(self.height()*ratio+.5)));image.setDevicePixelRatio(ratio);image.fill(Qt.GlobalColor.transparent)
        p=QPainter(image);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor('#f5f2f7'));p.drawRoundedRect(QRectF(self.rect()),10,10)
        single=len(self.items)==1
        for index,item in enumerate(self.items):
            rect=self.row_rect(index)
            if self.active==index:
                p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#e6dcec' if self.pressed else '#ede7f2'));p.drawRoundedRect(rect,7,7)
            y=(0 if single else index*48)+self.row_shift(index)
            p.setFont(font(11,True));p.setPen(MUTED)
            label='周' if not single and index==self.week_index and self.anomaly else item['label']
            p.drawText(QRectF(10,y+7,self.width()-20,18),Qt.AlignmentFlag.AlignVCenter,label)
            value=item['display'];color=quota_color(item) if item['low'] else INK
            p.setPen(color);p.setFont(font(28 if single else 18,True))
            value_rect=self.value_rect(index)
            # Very long custom decimal percentages remain legible and contained.
            for size in ((28,22,18,14,11) if single else (18,14,11,9)):
                p.setFont(font(size,True))
                if QFontMetrics(p.font()).horizontalAdvance(value)<=value_rect.width():break
            value=QFontMetrics(p.font()).elidedText(value,Qt.TextElideMode.ElideRight,int(value_rect.width()))
            p.drawText(value_rect,Qt.AlignmentFlag.AlignVCenter|(Qt.AlignmentFlag.AlignLeft if single else Qt.AlignmentFlag.AlignRight),value)
            self._track(p,self.track_rect(index),item)
            text=item['reset_text']
            if self.active==index and item['reset_at'] and not item['expired']:text=local_time(item['reset_at'])+' 重置'
            p.setPen(QColor('#98566d') if item['expired'] else MUTED);p.setFont(font(10 if single else 9))
            text=QFontMetrics(p.font()).elidedText(text,Qt.TextElideMode.ElideRight,self.width()-20)
            p.drawText(QRectF(10,80+y if single else y+36,self.width()-20,15),Qt.AlignmentFlag.AlignVCenter,text)
        p.end();self._static=image;self._static_key=key;self.layer_builds+=1
    def paintEvent(self,event):
        self.ensure_static();p=QPainter(self);p.drawPixmap(0,0,self._static);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen)
        for index,item in enumerate(self.items):
            progress=self.values[item['id']]
            if item['progress'] is not None and progress>0:
                rect=self.track_rect(index);filled=QRectF(rect.x(),rect.y(),rect.width()*progress,rect.height());radius=min(filled.width()/2,filled.height()/2)
                p.setBrush(quota_color(item));p.drawRoundedRect(filled,radius,radius)

class TodayTokens(QWidget):
    activated=Signal()
    HEIGHT=20
    def __init__(self,snapshot,parent=None,selected=False):
        super().__init__(parent);self.setObjectName('today_tokens');self.setFixedHeight(self.HEIGHT);self.data=today_tokens(snapshot);self.daily_only=bool(snapshot and snapshot.get('hourly_available') is False)
        self.hovered=False;self.pressed=False;self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.selected=None;self.set_selected(selected);self.setAccessibleDescription(self.data['description'])
    def set_selected(self,value):
        value=bool(value)
        if value==self.selected:return
        self.selected=value
        self.setAccessibleName('今日 Token '+self.data['display']+'；'+(('当前显示每日曲线' if value else '点击查看每日曲线') if self.daily_only else ('当前显示今日24小时曲线' if value else '点击查看今日24小时曲线')))
        self.update()
    def enterEvent(self,event):self.hovered=True;self.update();super().enterEvent(event)
    def leaveEvent(self,event):self.hovered=False;self.update();super().leaveEvent(event)
    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:self.pressed=True;self.update();event.accept()
    def mouseReleaseEvent(self,event):
        clicked=self.pressed and event.button()==Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint())
        self.pressed=False;self.update()
        if clicked:self.activated.emit()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor('#e6dcec' if self.pressed else '#e8def0' if self.selected else '#eee7f3' if self.hovered else '#f5f2f7'));p.drawRoundedRect(QRectF(self.rect()),6,6)
        p.setPen(MUTED);p.setFont(font(10));p.drawText(QRectF(8,0,69,self.height()),Qt.AlignmentFlag.AlignVCenter,'今日 Token')
        p.setFont(font(12,True));p.setPen(INK)
        value=self.data['display']+(' 部分' if self.data['partial'] else '')
        p.drawText(QRectF(77,0,self.width()-128,self.height()),Qt.AlignmentFlag.AlignVCenter,value)
        p.setPen(QColor('#75618d') if self.selected else MUTED);p.setFont(font(10,self.selected));p.drawText(QRectF(self.width()-45,0,37,self.height()),Qt.AlignmentFlag.AlignVCenter|Qt.AlignmentFlag.AlignRight,'按日 ›' if self.daily_only else '24h ›')
