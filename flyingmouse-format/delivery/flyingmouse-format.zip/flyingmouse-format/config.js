// config.js — 飞鼠格式服务端共享配置：引擎路径解析、目录、格式常量。
// 第一批抽取自 server.js（零逻辑改动，纯搬移）。

const fs = require("fs");
const os = require("os");
const path = require("path");

const ROOT = __dirname;
const DEFAULT_PORT = Number(process.env.PORT || 5177);
const RUNTIME_DIR = process.env.FLYINGMOUSE_RUNTIME_DIR || path.join(os.tmpdir(), "flyingmouse-format-runtime");
const UPLOAD_DIR = path.join(RUNTIME_DIR, "uploads");
const OUTPUT_DIR = path.join(RUNTIME_DIR, "converted");
const MAX_UPLOAD_BYTES = require("./resource-policy").LIMITS.maxUploadBytes;
// 运行时临时目录中「孤儿文件」的宽限期：cleanupOldFiles 只删不在 downloads 登记表、
// 且超过该时长未修改的文件；启动时超过该时长的历史实例目录也按此清理。
// 已登记产物在程序运行期间永不过期（2026-09-07 产品决策：用户指出「转换的文件
// 放在里面不该过期」，改为退出时 purge + 启动时清历史残留），本值不再是保存期限。
const PRODUCT_EXPIRY_MS = 1000 * 60 * 60 * 24;

function bundledFfmpegPath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_FFMPEG_PATH,
    resourcesPath && path.join(resourcesPath, "ffmpeg", "ffmpeg.exe"),
    path.join(ROOT, "bin", "ffmpeg", "ffmpeg.exe"),
    path.join(process.cwd(), "bin", "ffmpeg", "ffmpeg.exe")
  ].filter(Boolean);

  return candidates.find((candidate) => fs.existsSync(candidate)) || "ffmpeg";
}

function bundledLibreOfficePath() {
  // Store preparation fixes its writable destination before this module loads.
  // On a cold launch it does not exist yet; falling back by existence would bind
  // every converter to the read-only installation for the lifetime of the app.
  const preparedPath = require("./office-readiness").getOfficeState().path;
  if (preparedPath) return preparedPath;
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_LIBREOFFICE_PATH,
    resourcesPath && path.join(resourcesPath, "libreoffice", "LibreOfficePortable", "App", "libreoffice", "program", "soffice.com"),
    resourcesPath && path.join(resourcesPath, "libreoffice", "App", "libreoffice", "program", "soffice.com"),
    resourcesPath && path.join(resourcesPath, "libreoffice", "program", "soffice.com"),
    path.join(ROOT, "bin", "libreoffice", "LibreOfficePortable", "App", "libreoffice", "program", "soffice.com"),
    path.join(ROOT, "bin", "libreoffice", "App", "libreoffice", "program", "soffice.com"),
    path.join(ROOT, "bin", "libreoffice", "program", "soffice.com"),
    path.join(process.cwd(), "bin", "libreoffice", "LibreOfficePortable", "App", "libreoffice", "program", "soffice.com"),
    "soffice"
  ].filter(Boolean);

  return candidates.find((candidate) => candidate === "soffice" || fs.existsSync(candidate)) || "soffice";
}

function bundledPdftoppmPath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_PDFTOPPM_PATH,
    resourcesPath && path.join(resourcesPath, "poppler", "Library", "bin", "pdftoppm.exe"),
    resourcesPath && path.join(resourcesPath, "poppler", "bin", "pdftoppm.cmd"),
    path.join(ROOT, "bin", "poppler", "Library", "bin", "pdftoppm.exe"),
    path.join(ROOT, "bin", "poppler", "bin", "pdftoppm.cmd"),
    path.join(process.cwd(), "bin", "poppler", "Library", "bin", "pdftoppm.exe"),
    "pdftoppm"
  ].filter(Boolean);

  return candidates.find((candidate) => candidate === "pdftoppm" || fs.existsSync(candidate)) || "pdftoppm";
}

function bundledTessdataPath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_TESSDATA_PATH,
    resourcesPath && path.join(resourcesPath, "tessdata"),
    path.join(ROOT, "bin", "tessdata"),
    path.join(process.cwd(), "bin", "tessdata")
  ].filter(Boolean);

  return candidates.find((candidate) => fs.existsSync(path.join(candidate, "eng.traineddata.gz"))) || candidates[0] || "";
}

function bundledDcrawPath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_DCRAW_PATH,
    resourcesPath && path.join(resourcesPath, "dcraw", "dcraw.exe"),
    path.join(ROOT, "bin", "dcraw", "dcraw.exe"),
    path.join(process.cwd(), "bin", "dcraw", "dcraw.exe")
  ].filter(Boolean);

  return candidates.find((candidate) => fs.existsSync(candidate)) || "";
}

function bundledDocenginePath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_DOCENGINE_PATH,
    resourcesPath && path.join(resourcesPath, "docengine", "docengine.exe"),
    path.join(ROOT, "bin", "docengine", "docengine.exe"),
    path.join(process.cwd(), "bin", "docengine", "docengine.exe")
  ].filter(Boolean);

  return candidates.find((candidate) => fs.existsSync(candidate)) || "";
}

function bundledQpdfPath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_QPDF_PATH,
    resourcesPath && path.join(resourcesPath, "qpdf", "bin", "qpdf.exe"),
    path.join(ROOT, "bin", "qpdf", "extracted", "qpdf-12.4.0-msvc64", "bin", "qpdf.exe"),
    path.join(process.cwd(), "bin", "qpdf", "extracted", "qpdf-12.4.0-msvc64", "bin", "qpdf.exe"),
    "qpdf"
  ].filter(Boolean);

  return candidates.find((candidate) => candidate === "qpdf" || fs.existsSync(candidate)) || "qpdf";
}

function bundledDocstructureEnginePath() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_DOCSTRUCTURE_ENGINE_PATH,
    resourcesPath && path.join(resourcesPath, "docstructure", "docstructure-engine.exe"),
    path.join(ROOT, "bin", "docstructure", "docstructure-engine.exe"),
    path.join(process.cwd(), "bin", "docstructure", "docstructure-engine.exe")
  ].filter(Boolean);
  return candidates.find((candidate) => fs.existsSync(candidate)) || "";
}

function bundledDocstructureModelDir() {
  const resourcesPath = process.resourcesPath || "";
  const candidates = [
    process.env.FLYINGMOUSE_DOCSTRUCTURE_MODEL_DIR,
    resourcesPath && path.join(resourcesPath, "docstructure", "models"),
    path.join(ROOT, "bin", "docstructure", "models"),
    path.join(process.cwd(), "bin", "docstructure", "models")
  ].filter(Boolean);
  return candidates.find((candidate) => fs.existsSync(candidate)) || "";
}

const FFMPEG_PATH = bundledFfmpegPath();
const LIBREOFFICE_PATH = bundledLibreOfficePath();
const PDFTOPPM_PATH = bundledPdftoppmPath();
const TESSDATA_PATH = bundledTessdataPath();
const DCRAW_PATH = bundledDcrawPath();
const DOCENGINE_PATH = bundledDocenginePath();
const QPDF_PATH = bundledQpdfPath();
const DOCSTRUCTURE_ENGINE_PATH = bundledDocstructureEnginePath();
const DOCSTRUCTURE_MODEL_DIR = bundledDocstructureModelDir();

const imageInput = new Set(["jpg", "jpeg", "jfif", "jpe", "png", "webp", "gif", "avif", "tif", "tiff", "bmp", "heic", "heif", "ico", "tga", "svg", "jp2", "j2k", "jxl", "qoi", "ppm"]);
// 设计稿输入：.ai 本质是 PDF 封装（poppler 可直接栅格化，实测泰文包装稿无缺字），
// .psd 走 LibreOffice Draw 解码（实测图层合成完整）。统一归入 image 分类。
const designInput = new Set(["ai", "psd"]);
// 相机 RAW 原片（dcraw/libraw 可解码的常见扩展名）
const rawInput = new Set(["cr2", "cr3", "crw", "nef", "arw", "dng", "raf", "rw2", "orf", "pef", "srw", "3fr", "erf", "fff", "iiq", "kdc", "mef", "mrw", "x3f"]);
// tga/jp2/jxl/qoi/ppm 输出：sharp 的预编译编码器不全，统一走打包内置 ffmpeg。
const imageFormatTargets = ["png", "jpg", "webp", "gif", "avif", "tiff", "ico", "bmp", "tga", "jp2", "jxl", "qoi", "ppm", "pdf"];
const imageVideoTargets = ["mp4", "webm"];
const imageOcrTargets = ["txt", "docx", "md"];
const imageTargets = [...imageFormatTargets, ...imageVideoTargets, ...imageOcrTargets];
const textInput = new Set(["txt", "md", "markdown", "html", "htm", "json", "csv", "log", "xml", "yaml", "yml", "epub", "mobi"]);
const textTargets = ["txt", "md", "html", "json", "csv", "epub"];
const documentInput = new Set(["doc", "docx", "odt", "rtf", "wps", "wpt", "wpd", "ofd"]);
// OFD（国标 GB/T 33190）走自有转换链路（ofd-convert.js），仅支持转 PDF，不经 LibreOffice。
const ofdOnlyPdfTargets = ["pdf"];
const documentTargets = ["pdf", "docx", "odt", "rtf", "txt", "html", "md"];
const spreadsheetInput = new Set(["xls", "xlsx", "xlsm", "ods", "csv", "tsv", "et", "ett"]);
const spreadsheetTargets = ["pdf", "xlsx", "xls", "ods", "csv", "html"];
const presentationInput = new Set(["ppt", "pptx", "odp", "dps", "dpt"]);
const presentationTargets = ["pdf", "pptx", "odp", "html", "png", "jpg"];
const pdfInput = new Set(["pdf"]);
const pdfTextTargets = ["xlsx", "txt", "html", "docx", "md"];
const subtitleInput = new Set(["srt", "vtt", "ass", "ssa"]);
const subtitleTargets = ["srt", "vtt", "ass", "ssa", "txt"];
// webp 输出经 png 二跳（poppler 只出 png/jpg；sharp 有 webp 编码器）
const pdfImageTargets = ["png", "jpg", "webp"];
const pdfTargets = [...pdfTextTargets, ...pdfImageTargets, "pdf"];
const audioInput = new Set(["mp3", "wav", "flac", "m4a", "aac", "ogg", "opus", "wma"]);
// 注意（2026-08-15 起）：仅支持普通音频格式转换。其他音乐平台特殊格式
// （NCM/KGG/mflac/mgg/kgma/mmp4/kwm/vpr 等）已下架——这些是
// DRM 规避格式，存在法律风险，见 docs/分发与合规规范.md。
const videoInput = new Set(["mp4", "mov", "mkv", "webm", "avi", "m4v", "m4s", "wmv", "flv"]);
const mediaAudioTargets = ["mp3", "wav", "flac", "m4a", "ogg", "aac", "opus", "wma"];
const mediaVideoTargets = ["mp4", "webm", "mkv", "mov", "gif"];
const mediaTargets = [...mediaVideoTargets, ...mediaAudioTargets];
const experimentalInputsByCategory = Object.freeze({
  image: ["heic", "heif", "ico", "tga", "ai", "psd", "jp2", "j2k", "jxl", "qoi", "ppm"],
  raw: [...rawInput],
  document: ["wpd", "wps", "wpt"],
  spreadsheet: ["et", "ett"],
  presentation: ["dps", "dpt"],
  audio: []
});
const experimentalInputSet = new Set(Object.values(experimentalInputsByCategory).flat());
const allTargets = new Set([
  ...imageTargets,
  ...textTargets,
  ...documentTargets,
  ...spreadsheetTargets,
  ...presentationTargets,
  ...pdfTargets,
  ...subtitleTargets,
  ...mediaTargets
]);

// 运行时下载登记表（downloadUrlFor 写入 / 路由读取，跨模块共享同一实例）。
const downloads = new Map();

module.exports = {
  ROOT,
  DEFAULT_PORT,
  RUNTIME_DIR,
  UPLOAD_DIR,
  OUTPUT_DIR,
  MAX_UPLOAD_BYTES,
  PRODUCT_EXPIRY_MS,
  FFMPEG_PATH,
  LIBREOFFICE_PATH,
  PDFTOPPM_PATH,
  TESSDATA_PATH,
  DCRAW_PATH,
  DOCENGINE_PATH,
  QPDF_PATH,
  DOCSTRUCTURE_ENGINE_PATH,
  DOCSTRUCTURE_MODEL_DIR,
  imageInput,
  designInput,
  rawInput,
  imageFormatTargets,
  imageVideoTargets,
  imageOcrTargets,
  imageTargets,
  textInput,
  textTargets,
  documentInput,
  documentTargets,
  ofdOnlyPdfTargets,
  spreadsheetInput,
  spreadsheetTargets,
  presentationInput,
  presentationTargets,
  pdfInput,
  pdfTextTargets,
  pdfImageTargets,
  pdfTargets,
  subtitleInput,
  subtitleTargets,
  audioInput,
  videoInput,
  mediaAudioTargets,
  mediaVideoTargets,
  mediaTargets,
  experimentalInputsByCategory,
  experimentalInputSet,
  allTargets,
  downloads
};
