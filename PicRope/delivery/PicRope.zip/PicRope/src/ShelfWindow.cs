using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace ScreenLine
{
    internal enum ShotAction { Copy, Open, Edit, Remove, Trash, Save, Locate, RemoveLeft, RemoveRight, RemoveOthers, RemoveAll }

    internal sealed class ShelfWindow : Window
    {
        const double HiddenY = -300;
        readonly Gallery gallery;
        readonly Action<ShotAction, CaptureItem> act;
        internal readonly HoverPreview Preview;
        readonly ScrollViewer viewport = new ScrollViewer();
        readonly Canvas content = new Canvas();
        readonly Canvas line = new Canvas();
        readonly System.Windows.Shapes.Path rope = new System.Windows.Shapes.Path();
        readonly LinearGradientBrush edgeMask = new LinearGradientBrush(new GradientStopCollection {
            new GradientStop(Colors.White, 0), new GradientStop(Colors.White, 0.03),
            new GradientStop(Colors.White, 0.97), new GradientStop(Colors.White, 1)
        }, new Point(0, 0), new Point(1, 0));
        readonly Dictionary<string, ShotCard> cards = new Dictionary<string, ShotCard>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string, SimpleRopeCard> extraCards = new Dictionary<string, SimpleRopeCard>(StringComparer.OrdinalIgnoreCase);
        readonly Border hint = new Border();
        readonly Button enable = new Button();
        readonly TextBlock helpTitle = new TextBlock();
        readonly TextBlock helpDetail = new TextBlock();
        readonly TextBlock basketCount = new TextBlock();
        readonly Image basketImage = new Image { Width = 112, Stretch = Stretch.Uniform, IsHitTestVisible = false };
        readonly RotateTransform basketTurn = new RotateTransform();
        readonly ScaleTransform basketCounterScale = new ScaleTransform(1, 1);
        readonly SpringMotion basketMotion = new SpringMotion(0.5, 0.5, 0);
        readonly SpringMotion basketCounterMotion = new SpringMotion(0.28, 0.65, 1);
        int pendingPictures;
        readonly Button openBasket = new Button();
        internal readonly Button BasketButton = new Button();
        public event Action BasketRequested;
        internal readonly Button TextButton = new Button();
        readonly EnvelopeIcon envelopeImage = new EnvelopeIcon { Width = 96, Height = 86, Stretch = Stretch.Fill, IsHitTestVisible = false };
        readonly Canvas basketHolder, textHolder;
        readonly ClothesClip textClip = new ClothesClip();
        readonly TextBlock textCount = new TextBlock { FontFamily = new FontFamily("Segoe UI"), FontSize = 13, FontWeight = FontWeights.SemiBold, Foreground = Brushes.White, TextAlignment = TextAlignment.Center };
        readonly Border textCounter = new Border();
        public event Action TextRequested;
        public event Action RopeHidden;
        readonly TranslateTransform slide = new TranslateTransform(0, HiddenY);
        readonly SpringMotion revealMotion = new SpringMotion(0.42, 0.82, HiddenY);
        readonly SpringMotion ropeMotion = new SpringMotion(0.55, 0.78, 18);
        readonly SpringMotion scrollMotion = new SpringMotion(0.55, 0.78, 0);
        readonly Stopwatch clock = Stopwatch.StartNew();
        readonly Random random = new Random();
        readonly List<ShotFlight> flights = new List<ShotFlight>();
        readonly Dictionary<string, PinnedImageWindow> pins = new Dictionary<string, PinnedImageWindow>(StringComparer.OrdinalIgnoreCase);
        bool closing;
        readonly DispatcherTimer pointer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(30) };
        readonly DispatcherTimer scrollHover = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(120) };
        DateTime edgeSince = DateTime.MaxValue, awaySince = DateTime.MaxValue, peekUntil;
        DateTime nextGust;
        double lastFrame, hideTime, hideFrom, drawnWidth = -1, drawnSag = -1;
        double lastScrollOffset;
        bool rendering;
        bool pinned, previousDown, suppressEdge, trackingScrollHover, avoidingCaption, switchingDisplay, displayMoveQueued;
        int displaySwitchVersion;
        string viewingName;
        IntPtr viewingWindow;
        DateTime viewerSearchUntil;
        public bool Revealed { get; private set; }
        public IntPtr Handle { get; private set; }
        public Forms.Screen Display { get; private set; }
        public LineTheme Appearance { get; private set; }
        internal bool ChoosingAppearance { get; set; }
        internal bool ChoosingBasket { get; set; }
        internal bool ChoosingTexts { get; set; }
        internal bool Capturing { get; set; }
        double AccessoryWidth { get { return (gallery.Store.State.CollectClipboard ? 156 : 0) + (gallery.Store.State.CollectTextClipboard ? 104 : 0); } }
        double PhotoWidth { get { return Math.Max(1, (ActualWidth > 0 ? ActualWidth : Width) - 48 - AccessoryWidth); } }
        double LineWidth { get { return Math.Max(1, (ActualWidth > 0 ? ActualWidth : Width) - 48); } }
        double ScrollLimit { get { return Math.Max(0, content.Width - PhotoWidth); } }
        internal Point TextAnchor
        {
            get
            {
                if (!TextButton.IsVisible) return new Point(Display.WorkingArea.Right - 80, Display.WorkingArea.Top + 160 * WindowsNative.MonitorScale(Display));
                var point = textCounter.PointToScreen(new Point(textCounter.ActualWidth / 2, textCounter.ActualHeight + 4));
                point.Y -= slide.Y * WindowsNative.MonitorScale(Display);
                return point;
            }
        }

        public ShelfWindow(Gallery gallery, Action<ShotAction, CaptureItem> act, Action enableClipboard)
        {
            this.gallery = gallery;
            this.act = act;
            Preview = new HoverPreview(this, gallery.Store.State.HoverPreview);
            scrollHover.Tick += delegate
            {
                scrollHover.Stop(); trackingScrollHover = false;
                if (!Revealed || Mouse.LeftButton != MouseButtonState.Released || Mouse.RightButton != MouseButtonState.Released) return;
                var card = cards.Values.FirstOrDefault(item => item.Surface.IsMouseOver && !item.Grip.IsMouseOver);
                if (card != null) Preview.Enter(card);
            };
            Title = "PicRope · 图绳";
            Width = 1000;
            Height = 220;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ShowInTaskbar = false;
            ShowActivated = false;
            Topmost = true;
            viewport.HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden;
            viewport.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
            viewport.Content = content;
            viewport.Margin = new Thickness(24, 0, 284, 0);
            viewport.RenderTransform = slide;
            viewport.ScrollChanged += delegate(object sender, ScrollChangedEventArgs e)
            {
                if (e.HorizontalChange != 0)
                {
                    Preview.Dismiss();
                    if (trackingScrollHover) { scrollHover.Stop(); scrollHover.Start(); }
                }
                if (e.ExtentWidthChange != 0 || e.ViewportWidthChange != 0) lastScrollOffset = viewport.HorizontalOffset;
                foreach (var card in cards.Values) card.Frame(0, ropeMotion.Position, LineWidth, viewport.HorizontalOffset);
                foreach (var card in extraCards.Values) card.Frame(0, ropeMotion.Position, LineWidth, viewport.HorizontalOffset);
                UpdateEdgeMask();
            };
            viewport.PreviewMouseWheel += delegate(object sender, MouseWheelEventArgs e)
            {
                Preview.Dismiss();
                trackingScrollHover = true; scrollHover.Stop(); scrollHover.Start();
                double target = Math.Max(0, Math.Min(ScrollLimit, scrollMotion.Target - e.Delta));
                if (Math.Abs(target - scrollMotion.Target) > 0.01)
                {
                    scrollMotion.Target = target;
                    StartRendering();
                    nextGust = DateTime.UtcNow.AddSeconds(7 + random.NextDouble() * 17);
                }
                e.Handled = true;
            };
            var root = new Grid();
            line.Margin = new Thickness(24, 0, 24, 0); line.RenderTransform = slide; line.IsHitTestVisible = false;
            line.Children.Add(rope); root.Children.Add(line);
            root.Children.Add(viewport); Content = root;
            Appearance = LineTheme.FromId(gallery.Store.State.Theme);
            RopeLine.Apply(rope, Appearance);

            var basket = basketHolder = new Canvas { Width = 156, Height = 220, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 0, 24, 0), RenderTransform = slide };
            var basketBody = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            basketImage.Source = PictureBasket.Source(Appearance);
            RenderOptions.SetBitmapScalingMode(basketImage, BitmapScalingMode.HighQuality);
            basketImage.RenderTransform = basketTurn;
            Point hook = PictureBasket.Hook(Appearance); basketTurn.CenterX = hook.X; basketTurn.CenterY = hook.Y;
            basketImage.Height = 112 * basketImage.Source.Height / basketImage.Source.Width;
            basketBody.Children.Add(basketImage);
            basketCount.FontFamily = new FontFamily("Segoe UI"); basketCount.FontSize = 13; basketCount.FontWeight = FontWeights.SemiBold;
            basketCount.Foreground = Brushes.White; basketCount.TextAlignment = TextAlignment.Center;
            basketCount.RenderTransformOrigin = new Point(0.5, 0.5); basketCount.RenderTransform = basketCounterScale;
            basketBody.Children.Add(new Border { Child = basketCount, Background = LightTheme.Brush("#D920242C"),
                BorderBrush = LightTheme.Brush("#40FFFFFF"), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(6),
                Padding = new Thickness(6, 1, 6, 2), MinWidth = 26, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 6, 0, 0) });
            BasketButton.Content = basketBody; BasketButton.Width = 144; BasketButton.Height = 154; BasketButton.Focusable = false; BasketButton.Cursor = Cursors.Hand;
            BasketButton.ToolTip = "打开图片篮子";
            BasketButton.Template = (ControlTemplate)System.Windows.Markup.XamlReader.Parse("<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'><Border Background='#02FFFFFF'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Top'/></Border></ControlTemplate>");
            BasketButton.Click += delegate { if (BasketRequested != null) BasketRequested(); };
            BasketButton.MouseEnter += delegate { basketMotion.Target = 1.3; StartRendering(); };
            BasketButton.MouseLeave += delegate { basketMotion.Target = 0; };
            System.Windows.Automation.AutomationProperties.SetName(BasketButton, "打开图片篮子");
            basket.Children.Add(BasketButton); Canvas.SetLeft(BasketButton, 6); Canvas.SetTop(BasketButton, 20);
            root.Children.Add(basket);

            textHolder = new Canvas { Width = 112, Height = 220, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 0, 166, 0), RenderTransform = slide };
            var textBody = new Grid { Width = 96, Height = 154 };
            envelopeImage.Apply(Appearance);
            envelopeImage.HorizontalAlignment = HorizontalAlignment.Center; envelopeImage.VerticalAlignment = VerticalAlignment.Top;
            envelopeImage.Margin = new Thickness(0, 20, 0, 0);
            RenderOptions.SetBitmapScalingMode(envelopeImage, BitmapScalingMode.HighQuality); textBody.Children.Add(envelopeImage);
            textClip.Apply(Appearance, 2); textClip.HorizontalAlignment = HorizontalAlignment.Center; textClip.VerticalAlignment = VerticalAlignment.Top;
            textBody.Children.Add(textClip);
            textCounter.Child = textCount; textCounter.Background = LightTheme.Brush("#D920242C");
            textCounter.BorderBrush = LightTheme.Brush("#40FFFFFF"); textCounter.BorderThickness = new Thickness(1); textCounter.CornerRadius = new CornerRadius(6);
            textCounter.Padding = new Thickness(6, 1, 6, 2); textCounter.MinWidth = 26;
            textCounter.HorizontalAlignment = HorizontalAlignment.Center; textCounter.VerticalAlignment = VerticalAlignment.Top;
            textBody.Children.Add(textCounter);
            TextButton.Content = textBody; TextButton.Width = 96; TextButton.Height = 154; TextButton.Focusable = false; TextButton.Cursor = Cursors.Hand;
            TextButton.Template = BasketButton.Template; TextButton.ToolTip = "打开文字";
            TextButton.MouseEnter += delegate { envelopeImage.Expand(true); StartRendering(); };
            TextButton.MouseLeave += delegate { envelopeImage.Expand(false); };
            AutomationProperties.SetName(TextButton, "打开文字");
            TextButton.Click += delegate { if (TextRequested != null) TextRequested(); };
            textHolder.Children.Add(TextButton); Canvas.SetLeft(TextButton, 8);
            root.Children.Add(textHolder); UpdateTexts();

            var help = new StackPanel { Margin = new Thickness(20, 14, 20, 14) };
            helpTitle.FontSize = 15; helpTitle.FontWeight = FontWeights.SemiBold; helpTitle.Foreground = Brushes.Black; helpTitle.HorizontalAlignment = HorizontalAlignment.Center;
            helpDetail.FontSize = 12; helpDetail.Foreground = Brushes.DimGray; helpDetail.Margin = new Thickness(0, 8, 0, 12); helpDetail.HorizontalAlignment = HorizontalAlignment.Center;
            help.Children.Add(helpTitle); help.Children.Add(helpDetail);
            openBasket.Content = "打开图片篮子"; openBasket.Style = LightTheme.ButtonStyle; openBasket.Tag = "primary";
            openBasket.HorizontalAlignment = HorizontalAlignment.Center; openBasket.Margin = new Thickness(0, 0, 0, 8);
            openBasket.Click += delegate { if (BasketRequested != null) BasketRequested(); }; help.Children.Add(openBasket);
            enable.Content = "开启剪贴板收集";
            enable.Style = LightTheme.ButtonStyle;
            enable.Tag = "primary";
            enable.Padding = new Thickness(14, 5, 14, 5);
            enable.HorizontalAlignment = HorizontalAlignment.Center;
            enable.Focusable = false;
            enable.Click += delegate { enableClipboard(); Update(); };
            help.Children.Add(enable);
            hint.Child = help;
            hint.Width = 380;
            hint.Background = new SolidColorBrush(Color.FromArgb(248, 255, 255, 255));
            hint.CornerRadius = new CornerRadius(16);
            hint.BorderBrush = new SolidColorBrush(Color.FromRgb(218, 224, 232));
            hint.BorderThickness = new Thickness(1);
            hint.Effect = new DropShadowEffect { BlurRadius = 16, ShadowDepth = 3, Opacity = 0.18 };
            content.Children.Add(hint);

            SourceInitialized += delegate
            {
                Handle = new WindowInteropHelper(this).Handle;
                WindowsNative.PrepareOverlay(Handle);
                WindowsNative.PassMouse(Handle, true);
                HwndSource.FromHwnd(Handle).AddHook(Messages);
                MoveToDisplay();
                pointer.Start();
            };
            Loaded += delegate { Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(delegate { if (!closing) MoveToDisplay(); })); };
            SizeChanged += delegate { UpdateAccessories(); LayoutCards(); };
            pointer.Tick += Tick;
            gallery.Changed += Update;
            Microsoft.Win32.SystemEvents.DisplaySettingsChanged += DisplaysChanged;
            Closed += delegate
            {
                closing = true;
                CancelDisplaySwitch();
                scrollHover.Stop(); trackingScrollHover = false;
                Preview.Dispose();
                foreach (var pin in pins.Values.ToArray()) pin.Close();
                pointer.Stop();
                StopRendering();
                foreach (var flight in flights.ToArray()) flight.Close();
                gallery.Changed -= Update;
                Microsoft.Win32.SystemEvents.DisplaySettingsChanged -= DisplaysChanged;
                foreach (var card in cards.Values) card.Dispose();
            };
            Update();
        }

        IntPtr Messages(IntPtr window, int message, IntPtr w, IntPtr l, ref bool handled)
        {
            if (message == 0x21) { handled = true; return new IntPtr(3); }
            if (message == 0x02E0 && !switchingDisplay) Dispatcher.BeginInvoke(new Action(delegate { if (Display != null && !switchingDisplay) MoveToDisplay(); }));
            return IntPtr.Zero;
        }

        void DisplaysChanged(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(new Action(MoveToDisplay));
        }

        Forms.Screen SelectedDisplay()
        {
            string device = gallery.Store.State.DisplayDevice;
            if (string.IsNullOrEmpty(device)) return WindowsNative.ScreenAtPointer();
            var screens = WindowsNative.Screens;
            return Array.Find(screens, screen => screen.DeviceName == device) ?? Array.Find(screens, screen => screen.Primary);
        }

        void MoveToDisplay()
        {
            CancelDisplaySwitch();
            PositionOnDisplay();
        }

        void PositionOnDisplay()
        {
            scrollHover.Stop(); trackingScrollHover = false;
            Preview.Dismiss();
            var screen = SelectedDisplay();
            Display = screen;
            double scale = WindowsNative.MonitorScale(screen);
            Height = 220;
            Width = screen.WorkingArea.Width / scale;
            if (Handle != IntPtr.Zero)
                WindowsNative.SetWindowPos(Handle, new IntPtr(-1), screen.WorkingArea.Left, screen.WorkingArea.Top, screen.WorkingArea.Width, (int)Math.Round(220 * scale), 0x10);
            LayoutCards();
        }

        internal void SetDisplay(string device)
        {
            string previous = gallery.Store.State.DisplayDevice;
            gallery.Store.State.DisplayDevice = device;
            try { gallery.Store.Save(); }
            catch { gallery.Store.State.DisplayDevice = previous; throw; }
            MoveToDisplay();
            Reveal(true, true, 0);
        }

        internal void SetRevealOnTopHover(bool enabled)
        {
            bool previous = gallery.Store.State.RevealOnTopHover;
            gallery.Store.State.RevealOnTopHover = enabled;
            try { gallery.Store.Save(); }
            catch { gallery.Store.State.RevealOnTopHover = previous; throw; }
            edgeSince = DateTime.MaxValue;
            // 跨屏收起也是顶部悬停发起的，关闭时取消尚未完成的自动展开。
            if (!enabled) CancelDisplaySwitch();
        }

        public void Update()
        {
            Preview.Dismiss();
            UpdateAccessories();
            var retained = new HashSet<string>(gallery.Items.Select(i => i.Path), StringComparer.OrdinalIgnoreCase);
            foreach (string gone in cards.Keys.Where(k => !retained.Contains(k)).ToArray())
            {
                cards[gone].Dispose();
                PinnedImageWindow pin;
                if (pins.TryGetValue(gone, out pin)) pin.Close();
                content.Children.Remove(cards[gone]);
                cards.Remove(gone);
            }
            foreach (var item in gallery.Items)
            {
                ShotCard card;
                if (!cards.TryGetValue(item.Path, out card))
                {
                    card = new ShotCard(item, act, gallery, HangingItems);
                    var hovered = card;
                    card.Surface.MouseEnter += delegate { Preview.Enter(hovered); };
                    card.Surface.MouseLeave += delegate { Preview.Leave(hovered); };
                    card.PreviewMouseDown += delegate { scrollHover.Stop(); trackingScrollHover = false; Preview.Dismiss(); };
                    card.Grip.MouseEnter += delegate { Preview.Dismiss(); };
                    card.ApplyTheme(Appearance, gallery.Items.IndexOf(item));
                    var mounted = card;
                    card.Grip.Click += async delegate { await ReleasePhoto(mounted); };
                    card.ReorderRequested = delegate(ShotCard moving, double targetX) { Reorder(moving, targetX); };
                    cards.Add(item.Path, card);
                    content.Children.Add(card);
                }
                bool changed = card.UpdateImage();
                PinnedImageWindow pinnedImage;
                if (changed && pins.TryGetValue(item.Path, out pinnedImage)) pinnedImage.UpdateImage();
            }
            hint.Visibility = gallery.Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            helpTitle.Text = gallery.Store.State.AutoHang ? "截图会挂在这里" : "从图片篮子里挑几张挂上";
            helpDetail.Text = gallery.Store.State.AutoHang ? "Win + PrtScn · 或开启剪贴板截图收集" : "截图会先收好，需要时再挂上绳子";
            openBasket.Visibility = gallery.Store.State.AutoHang ? Visibility.Collapsed : Visibility.Visible;
            int pending = gallery.Collected.Count(i => !gallery.Contains(i.Path));
            if (pending > pendingPictures && Revealed && !flights.Any(flight => flight.Collecting || flight.Falling)) BasketReceived();
            pendingPictures = pending; basketCount.Text = pending.ToString();
            System.Windows.Automation.AutomationProperties.SetItemStatus(BasketButton, basketCount.Text + " 张待挂");
            enable.Visibility = gallery.Store.State.CollectClipboard ? Visibility.Collapsed : Visibility.Visible;
            SyncExtras();
            LayoutCards();
        }

        void LayoutCards()
        {
            double available = PhotoWidth;
            var hanging = gallery.Items.Where(item => !cards[item.Path].Detached).ToArray();
            var extras = OrderedExtraKeys().Select(key => extraCards[key]).ToArray();
            int total = hanging.Length + extras.Length;
            content.Width = Math.Max(available, total * 172 + 32);
            content.Height = 220;
            scrollMotion.Target = Math.Max(0, Math.Min(ScrollLimit, scrollMotion.Target));
            if (ScrollLimit == 0) { scrollMotion.Snap(0); viewport.ScrollToHorizontalOffset(0); lastScrollOffset = 0; }
            else if (scrollMotion.Position > ScrollLimit) { scrollMotion.Position = ScrollLimit; scrollMotion.Velocity = 0; }
            ropeMotion.Target = 18 + Math.Min(7, total) * 1.2;
            if (!Revealed) ropeMotion.Snap(ropeMotion.Target);
            DrawRope();
            Canvas.SetLeft(hint, (content.Width - hint.Width) / 2);
            Canvas.SetTop(hint, 56);
            for (int i = 0; i < hanging.Length; i++)
            {
                ShotCard card = cards[hanging[i].Path];
                double x = (content.Width - total * 172) / 2 + i * 172;
                card.Place(x, !Revealed);
                card.Frame(0, ropeMotion.Position, LineWidth, viewport.HorizontalOffset);
            }
            for (int i = 0; i < extras.Length; i++)
            {
                double x = (content.Width - total * 172) / 2 + (hanging.Length + i) * 172;
                extras[i].Place(x, !Revealed);
                extras[i].Frame(0, ropeMotion.Position, LineWidth, viewport.HorizontalOffset);
            }
        }

        IEnumerable<string> OrderedExtraKeys()
        {
            foreach (string path in gallery.Store.State.Files)
            {
                string key = "file:" + path;
                if (extraCards.ContainsKey(key)) yield return key;
            }
            foreach (string text in gallery.Store.State.RopeTexts)
            {
                string key = "text:" + text;
                if (extraCards.ContainsKey(key)) yield return key;
            }
        }

        internal CaptureItem[] HangingItems()
        {
            return gallery.Items.Where(item => cards.ContainsKey(item.Path) && !cards[item.Path].Detached).ToArray();
        }

        // 松手后根据水平落点把卡片移到新位置，顺序写入 state.Images 持久保留。
        void Reorder(ShotCard moving, double targetX)
        {
            var hanging = gallery.Items.Where(item => !cards[item.Path].Detached).ToArray();
            if (hanging.Length < 2) { LayoutCards(); return; }
            var extras = OrderedExtraKeys().Select(key => extraCards[key]).ToArray();
            int total = hanging.Length + extras.Length;
            double firstX = (content.Width - total * 172) / 2;
            int index = (int)Math.Round((targetX - firstX) / 172.0);
            index = Math.Max(0, Math.Min(hanging.Length - 1, index));
            int from = Array.IndexOf(hanging, moving.Item);
            if (from >= 0 && from != index) gallery.Move(moving.Item, index);
            else LayoutCards();
        }

        void SyncExtras()
        {
            var retained = new HashSet<string>(OrderedExtraKeys(), StringComparer.OrdinalIgnoreCase);
            foreach (string gone in extraCards.Keys.Where(k => !retained.Contains(k)).ToArray())
            {
                extraCards[gone].Dispose();
                content.Children.Remove(extraCards[gone]);
                extraCards.Remove(gone);
            }
            foreach (string path in gallery.Store.State.Files) EnsureExtraCard("file:" + path);
            foreach (string text in gallery.Store.State.RopeTexts) EnsureExtraCard("text:" + text);
        }

        void EnsureExtraCard(string key)
        {
            if (extraCards.ContainsKey(key)) return;
            bool isFile = key.StartsWith("file:", StringComparison.Ordinal);
            var card = new SimpleRopeCard(key, key.Substring(5), isFile ? SimpleRopeCard.RopeKind.File : SimpleRopeCard.RopeKind.Text, RemoveExtra);
            extraCards.Add(key, card);
            content.Children.Add(card);
        }

        void RemoveExtra(string key)
        {
            SimpleRopeCard card;
            if (!extraCards.TryGetValue(key, out card)) return;
            extraCards.Remove(key);
            content.Children.Remove(card);
            card.Dispose();
            var state = gallery.Store.State;
            if (key.StartsWith("file:", StringComparison.Ordinal))
            {
                string path = key.Substring(5);
                if (state.Files.RemoveAll(item => string.Equals(item, path, StringComparison.OrdinalIgnoreCase)) > 0) { gallery.Store.Save(); LayoutCards(); }
            }
            else
            {
                string text = key.Substring(5);
                if (state.RopeTexts.RemoveAll(item => item == text) > 0) { gallery.Store.Save(); LayoutCards(); }
            }
        }

        internal int AddFiles(IEnumerable<string> paths)
        {
            var state = gallery.Store.State;
            if (state.Files == null) state.Files = new List<string>();
            int added = 0;
            foreach (string path in paths)
            {
                string full;
                try { full = System.IO.Path.GetFullPath(path); } catch { continue; }
                if (!System.IO.File.Exists(full)) continue;
                if (state.Files.Any(item => string.Equals(item, full, StringComparison.OrdinalIgnoreCase))) continue;
                state.Files.Add(full); added++;
            }
            if (added > 0) { gallery.Store.Save(); SyncExtras(); LayoutCards(); StartRendering(); }
            return added;
        }

        internal void AddRopeText(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            var state = gallery.Store.State;
            if (state.RopeTexts == null) state.RopeTexts = new List<string>();
            if (state.RopeTexts.Contains(text)) return;
            state.RopeTexts.Add(text);
            gallery.Store.Save();
            SyncExtras(); LayoutCards(); StartRendering();
        }

        public void ApplyTheme(LineTheme theme)
        {
            Appearance = theme;
            RopeLine.Apply(rope, theme);
            basketImage.Source = PictureBasket.Source(theme);
            basketImage.Height = 112 * basketImage.Source.Height / basketImage.Source.Width;
            envelopeImage.Apply(theme); textClip.Apply(theme, 2);
            Point hook = PictureBasket.Hook(theme); basketTurn.CenterX = hook.X; basketTurn.CenterY = hook.Y;
            drawnWidth = -1; DrawRope();
            for (int i = 0; i < gallery.Items.Count; i++) cards[gallery.Items[i].Path].ApplyTheme(theme, i);
            foreach (var flight in flights) flight.ApplyTheme(theme);
            foreach (var entry in pins) entry.Value.ApplyTheme(theme, cards[entry.Key].ColorIndex);
        }

        void DrawRope()
        {
            if (Math.Abs(drawnWidth - LineWidth) < 0.01 && Math.Abs(drawnSag - ropeMotion.Position) < 0.01) return;
            drawnWidth = LineWidth;
            drawnSag = ropeMotion.Position;
            var geometry = new PathGeometry();
            var shape = new PathFigure { StartPoint = new Point(0, 18) };
            shape.Segments.Add(new QuadraticBezierSegment(new Point(drawnWidth / 2, 18 + 2 * drawnSag), new Point(drawnWidth, 18), true));
            geometry.Figures.Add(shape);
            rope.Data = geometry;
            Point hook = PictureBasket.Hook(Appearance);
            double fraction = (PhotoWidth + AccessoryWidth - 156 + 22 + hook.X) / LineWidth;
            double offset = 4 * drawnSag * fraction * (1 - fraction);
            double basketTop = 18 + offset - hook.Y;
            Canvas.SetTop(BasketButton, basketTop);
            double textFraction = (PhotoWidth + (gallery.Store.State.CollectClipboard ? 62 : 48)) / LineWidth;
            double textTop = 18 + 4 * drawnSag * textFraction * (1 - textFraction) - 7;
            Canvas.SetTop(TextButton, textTop);
            double countTop = basketTop + basketImage.Height + 6 - textTop;
            textCounter.Margin = new Thickness(0, countTop, 0, 0);
            envelopeImage.Height = Math.Max(24, Math.Min(86, countTop - 26));
        }

        internal void UpdateTexts()
        {
            UpdateAccessories();
            textCount.Text = gallery.Store.State.Texts.Count.ToString();
            AutomationProperties.SetItemStatus(TextButton, textCount.Text + " 条文字");
            if (Display != null) LayoutCards();
        }

        void UpdateAccessories()
        {
            bool pictures = gallery.Store.State.CollectClipboard, texts = gallery.Store.State.CollectTextClipboard;
            BasketButton.Visibility = basketHolder.Visibility = pictures ? Visibility.Visible : Visibility.Collapsed;
            TextButton.Visibility = textHolder.Visibility = texts ? Visibility.Visible : Visibility.Collapsed;
            basketHolder.Margin = new Thickness(0, 0, 24, 0);
            textHolder.Margin = new Thickness(0, 0, pictures ? 166 : 24, 0);
            viewport.Margin = new Thickness(24, 0, 24 + AccessoryWidth, 0);
            if (!pictures) { basketMotion.Snap(0); basketCounterMotion.Snap(1); }
            if (!texts) envelopeImage.Reset();
            drawnWidth = -1;
        }

        void UpdateEdgeMask()
        {
            double fade = Math.Min(0.08, 18 / PhotoWidth);
            edgeMask.GradientStops[0].Color = viewport.HorizontalOffset > 1 ? Colors.Transparent : Colors.White;
            edgeMask.GradientStops[1].Offset = fade;
            edgeMask.GradientStops[2].Offset = 1 - fade;
            edgeMask.GradientStops[3].Color = viewport.HorizontalOffset < ScrollLimit - 1 ? Colors.Transparent : Colors.White;
            viewport.OpacityMask = ScrollLimit > 0 ? edgeMask : null;
        }

        public void Toggle()
        {
            viewingName = null;
            viewingWindow = IntPtr.Zero;
            if (Revealed) Reveal(false, false, 0);
            else { MoveToDisplay(); Reveal(true, true, 0); }
        }

        public void FollowImageViewer(string path)
        {
            viewingName = System.IO.Path.GetFileName(path);
            viewingWindow = IntPtr.Zero;
            viewerSearchUntil = DateTime.UtcNow.AddSeconds(5);
            awaySince = DateTime.MaxValue;
        }

        bool ViewingImage(DateTime now)
        {
            if (viewingName == null) return false;
            IntPtr foreground = WindowsNative.GetForegroundWindow();
            if (viewingWindow == IntPtr.Zero)
            {
                if (foreground != Handle && WindowsNative.WindowTitle(foreground).IndexOf(viewingName, StringComparison.OrdinalIgnoreCase) >= 0)
                    viewingWindow = foreground;
                else if (now < viewerSearchUntil) return true;
                else { viewingName = null; return false; }
            }
            if (!WindowsNative.IsWindowVisible(viewingWindow))
            {
                viewingName = null;
                viewingWindow = IntPtr.Zero;
                Reveal(true, false, 0);
                return true;
            }
            return foreground == viewingWindow;
        }

        public void ShowNewCapture(CaptureItem item, Point? origin)
        {
            MoveToDisplay();
            Reveal(true, false, 2);
            scrollMotion.Target = ScrollLimit;
            ropeMotion.Velocity += 8;
            if (!Revealed || !origin.HasValue || flights.Count(f => !f.Falling && !f.Collecting) >= 2) return;
            ShotCard card = cards[item.Path];
            if (card.Detached) return;
            card.BeginFlight();
            var bounds = Display.Bounds;
            double scale = Math.Min(1, Math.Min(bounds.Width * 0.7 / item.Image.PixelWidth, bounds.Height * 0.7 / item.Image.PixelHeight));
            double width = item.Image.PixelWidth * scale, height = item.Image.PixelHeight * scale;
            double left = Math.Max(bounds.Left, Math.Min(bounds.Right - width, origin.Value.X - width));
            double top = Math.Max(bounds.Top, Math.Min(bounds.Bottom - height, origin.Value.Y - height));
            Rect start = new Rect(left, top, width, height);
            if (item.Image.PixelWidth == bounds.Width && item.Image.PixelHeight == bounds.Height)
                start = new Rect(bounds.Left, bounds.Top, bounds.Width, bounds.Height);
            PlayFlight(new ShotFlight(Display, card, start, false, card.Land));
        }

        public void ShowDiscard(CaptureItem item)
        {
            ShotCard card;
            if (!Revealed || !cards.TryGetValue(item.Path, out card) || card.Flying) return;
            PlayFlight(new ShotFlight(Display, card, card.PhotoRect(), true, delegate { }));
        }

        public void ShowCollect(CaptureItem item)
        {
            if (!gallery.Store.State.CollectClipboard) return;
            ShotCard card;
            if (!Revealed || !cards.TryGetValue(item.Path, out card) || card.Flying) return;
            peekUntil = DateTime.UtcNow.AddSeconds(2);
            PlayFlight(new ShotFlight(Display, card, card.PhotoRect(), false, BasketReceived, null, delegate
            {
                Point mouth = basketImage.PointToScreen(PictureBasket.Mouth(Appearance));
                double scale = WindowsNative.MonitorScale(Display);
                return new Rect(mouth.X - 28 * scale, mouth.Y, 56 * scale, 16 * scale);
            }));
        }

        void BasketReceived()
        {
            if (closing || !Revealed || !gallery.Store.State.CollectClipboard) return;
            basketMotion.Velocity = Math.Max(-48, basketMotion.Velocity - 32);
            basketCounterMotion.Velocity = Math.Min(2, basketCounterMotion.Velocity + 1.2);
            StartRendering();
        }

        public void ShowEditedImage(string path, Rect origin, BitmapSource picture)
        {
            ShotCard card;
            if (closing || !cards.TryGetValue(path, out card) || card.Detached || card.Flying) return;
            MoveToDisplay();
            Reveal(true, false, 2);
            if (!Revealed) return;
            card.BeginFlight();
            LayoutCards();
            viewport.UpdateLayout();
            scrollMotion.Target = Math.Max(0, Math.Min(content.Width - viewport.ViewportWidth, card.MountX + 82 - viewport.ViewportWidth / 2));
            PlayFlight(new ShotFlight(Display, card, origin, false, delegate { card.Land(); ropeMotion.Velocity += 12; }, picture));
        }

        void PlayFlight(ShotFlight flight)
        {
            flights.Add(flight);
            flight.Closed += delegate { flights.Remove(flight); };
            flight.Show();
        }

        async Task ReleasePhoto(ShotCard card)
        {
            if (card.Releasing || card.Flying || card.Detached) return;
            Rect origin = card.PhotoRect();
            card.OpenClip();
            awaySince = DateTime.MaxValue;
            try
            {
                var picture = Task.Run(() => PinnedImageWindow.ReadPicture(card.Item.Path));
                await Task.Delay(40);
                var image = await picture;
                if (closing || card.IsDisposed) return;
                var window = new PinnedImageWindow(card.Item, origin, ((RotateTransform)card.RenderTransform).Angle, image, Appearance, card.ColorIndex);
                pins.Add(card.Item.Path, window);
                window.Closed += delegate
                {
                    pins.Remove(card.Item.Path);
                    if (closing || card.IsDisposed) return;
                    card.Detached = false;
                    card.ResetClip();
                    card.BeginFlight();
                    var bounds = window.ReturnBounds;
                    MoveToDisplay();
                    Reveal(true, false, 3);
                    LayoutCards();
                    viewport.UpdateLayout();
                    scrollMotion.Target = Math.Max(0, Math.Min(content.Width - viewport.ViewportWidth, card.MountX + 82 - viewport.ViewportWidth / 2));
                    PlayFlight(new ShotFlight(Display, card, bounds, false, card.Land, window.Picture));
                };
                card.DetachPhoto();
                ropeMotion.Velocity -= 24;
                LayoutCards();
                window.Show();
            }
            catch (Exception error) { gallery.Store.Log(error); card.ResetClip(); }
        }

        void CancelDisplaySwitch()
        {
            if (switchingDisplay || displayMoveQueued) edgeSince = DateTime.MaxValue;
            switchingDisplay = false;
            displayMoveQueued = false;
            displaySwitchVersion++;
        }

        public void Reveal(bool shown, bool pin, double seconds)
        {
            CancelDisplaySwitch();
            pinned = pin;
            peekUntil = DateTime.UtcNow.AddSeconds(seconds);
            awaySince = DateTime.MaxValue;
            if (shown && WindowsNative.FullScreen(Display, Handle)) return;
            if (shown == Revealed) return;
            if (shown) avoidingCaption = false;
            Revealed = shown;
            revealMotion.Target = shown ? 0 : HiddenY;
            hideFrom = revealMotion.Position;
            hideTime = 0;
            StartRendering();
            if (!shown)
            {
                scrollHover.Stop(); trackingScrollHover = false;
                Preview.Dismiss();
                if (RopeHidden != null) RopeHidden();
                foreach (var flight in flights.ToArray()) flight.Close();
                basketMotion.Snap(0); basketTurn.Angle = 0;
                basketCounterMotion.Snap(1); basketCounterScale.ScaleX = basketCounterScale.ScaleY = 1;
                envelopeImage.Reset();
                WindowsNative.PassMouse(Handle, true);
            }
            else
            {
                if (nextGust == default(DateTime)) nextGust = DateTime.UtcNow.AddSeconds(7 + random.NextDouble() * 17);
                foreach (var card in cards.Values) card.Nudge(1.2);
            }
        }

        internal bool HookHover { get; private set; }

        internal void SetHookHover(bool value) { HookHover = value; }

        // 供挂钩窗判断鼠标是否已经移到绳子上，避免从挂钩往下移时绳子先收起。
        internal bool HoveringContents(WindowsNative.Point cursor)
        {
            if (!Revealed) return false;
            WindowsNative.Rectangle bounds;
            if (!WindowsNative.GetWindowRect(Handle, out bounds)) return false;
            if (cursor.X >= bounds.Left && cursor.X < bounds.Right && cursor.Y >= bounds.Top && cursor.Y < bounds.Bottom) return true;
            return OverControl(cursor);
        }

        void StartRendering()
        {
            if (rendering) return;
            rendering = true;
            lastFrame = clock.Elapsed.TotalSeconds;
            CompositionTarget.Rendering += RenderFrame;
        }

        void StopRendering()
        {
            if (!rendering) return;
            rendering = false;
            CompositionTarget.Rendering -= RenderFrame;
        }

        bool NeedsRendering
        {
            get
            {
                return !revealMotion.Settled || !ropeMotion.Settled || !scrollMotion.Settled || !basketMotion.Settled
                    || !basketCounterMotion.Settled || (gallery.Store.State.CollectTextClipboard && envelopeImage.Animating)
                    || cards.Values.Any(card => card.Animating)
                    || extraCards.Values.Any(card => card.Animating);
            }
        }

        void RenderFrame(object sender, EventArgs args)
        {
            double now = clock.Elapsed.TotalSeconds;
            double elapsed = now - lastFrame;
            lastFrame = now;
            if (Revealed) revealMotion.Step(elapsed);
            else
            {
                hideTime += elapsed;
                double t = Math.Min(1, hideTime / 0.22);
                double remaining = 1 - t;
                revealMotion.Position = hideFrom + (HiddenY - hideFrom) * (1 - remaining * remaining * remaining);
                revealMotion.Velocity = 3 * (HiddenY - hideFrom) * remaining * remaining / 0.22;
                if (t == 1) revealMotion.Snap(HiddenY);
            }
            slide.Y = revealMotion.Position;
            if (!Revealed)
            {
                if (hideTime >= 0.22) StopRendering();
                return;
            }
            ropeMotion.Step(elapsed);
            DrawRope();
            basketMotion.Step(elapsed); basketTurn.Angle = basketMotion.Position;
            basketCounterMotion.Step(elapsed); basketCounterScale.ScaleX = basketCounterScale.ScaleY = basketCounterMotion.Position;
            if (gallery.Store.State.CollectTextClipboard) envelopeImage.Frame(elapsed);
            scrollMotion.Target = Math.Max(0, Math.Min(scrollMotion.Target, ScrollLimit));
            scrollMotion.Step(elapsed);
            if (scrollMotion.Position < 0 || scrollMotion.Position > ScrollLimit)
            {
                scrollMotion.Position = Math.Max(0, Math.Min(scrollMotion.Position, ScrollLimit));
                scrollMotion.Velocity = 0;
            }
            viewport.ScrollToHorizontalOffset(scrollMotion.Position);
            double scrollVelocity = Revealed && elapsed > 0 ? (viewport.HorizontalOffset - lastScrollOffset) / elapsed : 0;
            lastScrollOffset = viewport.HorizontalOffset;
            foreach (var card in cards.Values)
            {
                card.ScrollWith(scrollVelocity);
                card.Frame(elapsed, ropeMotion.Position, LineWidth, viewport.HorizontalOffset);
            }
            foreach (var card in extraCards.Values) card.Frame(elapsed, ropeMotion.Position, LineWidth, viewport.HorizontalOffset);
            if (!NeedsRendering) StopRendering();
        }

        bool OverControl(WindowsNative.Point cursor)
        {
            Point local = PointFromScreen(new Point(cursor.X, cursor.Y));
            var photoArea = viewport.TransformToAncestor(this).TransformBounds(new Rect(viewport.RenderSize));
            IEnumerable<FrameworkElement> targets = cards.Values.Where(c => !c.Flying && !c.Detached).SelectMany(c => new FrameworkElement[] { c.Surface, c.Grip });
            if (hint.IsVisible) targets = targets.Concat(new[] { hint });
            targets = targets.Concat(new[] { BasketButton, TextButton }.Where(button => button.IsVisible));
            foreach (var target in targets)
            {
                var bounds = target.TransformToAncestor(this).TransformBounds(new Rect(0, 0, target.ActualWidth, target.ActualHeight));
                if (target != BasketButton && target != TextButton) bounds.Intersect(photoArea);
                if (bounds.Contains(local)) return true;
            }
            return false;
        }

        void Tick(object sender, EventArgs args)
        {
            if (Capturing) { CancelDisplaySwitch(); edgeSince = DateTime.MaxValue; return; }
            var cursor = WindowsNative.Cursor();
            var screen = SelectedDisplay();
            bool down = (WindowsNative.GetAsyncKeyState(1) & 0x8000) != 0;
            // 只有悬浮屏幕顶端那个具体的木夹挂钩时才展开，不再整条屏幕顶边都触发。
            bool nearTop = HookHover && gallery.Store.State.RevealOnTopHover;
            var interval = TimeSpan.FromMilliseconds(Revealed || nearTop ? 30 : 100);
            if (pointer.Interval != interval) pointer.Interval = interval;
            bool over = Revealed && OverControl(cursor);
            var now = DateTime.UtcNow;
            bool viewing = ViewingImage(now);
            bool busy = cards.Values.Any(c => c.Busy);
            if (!nearTop) suppressEdge = false;
            if (nearTop && down && !previousDown && !over && !viewing)
            {
                suppressEdge = true;
                edgeSince = DateTime.MaxValue;
                viewingName = null;
                viewingWindow = IntPtr.Zero;
                Reveal(false, false, 0);
            }
            previousDown = down;
            if (switchingDisplay)
            {
                if (hideTime >= 0.22 && !displayMoveQueued)
                {
                    displayMoveQueued = true;
                    int version = displaySwitchVersion;
                    PositionOnDisplay();
                    Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(delegate
                    {
                        if (version != displaySwitchVersion) return;
                        displayMoveQueued = false;
                        if (!switchingDisplay || closing || Capturing) { CancelDisplaySwitch(); return; }
                        if ((WindowsNative.GetAsyncKeyState(1) & 0x8000) != 0 || suppressEdge)
                        {
                            suppressEdge = true; previousDown = true;
                            CancelDisplaySwitch(); return;
                        }
                        PositionOnDisplay();
                        var selected = SelectedDisplay();
                        if (WindowsNative.OverCaptionButtons(selected, WindowsNative.Cursor(), Handle)
                            || WindowsNative.FullScreen(selected, Handle)) { CancelDisplaySwitch(); return; }
                        Reveal(true, false, 0);
                    }));
                }
                return;
            }
            if ((Revealed || nearTop || avoidingCaption) && !busy && !viewing && !ChoosingAppearance && !ChoosingBasket && !ChoosingTexts
                && WindowsNative.OverCaptionButtons(screen, cursor, Handle))
            {
                edgeSince = DateTime.MaxValue; previousDown = down;
                if (Revealed) { avoidingCaption = true; Reveal(false, false, 0); }
                return;
            }
            if (avoidingCaption && !down && hideTime >= 0.22)
            {
                avoidingCaption = false;
                if (cursor.X >= Display.Bounds.Left && cursor.X < Display.Bounds.Right
                    && cursor.Y >= Display.WorkingArea.Top && cursor.Y < Display.WorkingArea.Top + 220 * WindowsNative.MonitorScale(Display))
                    Reveal(true, false, 0);
            }
            if (gallery.Store.State.RevealOnTopHover && nearTop && !down && !suppressEdge && !WindowsNative.FullScreen(screen, Handle))
            {
                if (edgeSince == DateTime.MaxValue) edgeSince = now;
                if (now - edgeSince >= TimeSpan.FromMilliseconds(320) && (!Revealed || screen.DeviceName != Display.DeviceName))
                {
                    if (Revealed && screen.DeviceName != Display.DeviceName)
                    {
                        Reveal(false, false, 0);
                        switchingDisplay = true;
                        return;
                    }
                    else { MoveToDisplay(); Reveal(true, false, 0); }
                }
            }
            else edgeSince = DateTime.MaxValue;
            if (WindowsNative.FullScreen(Display, Handle)) { Reveal(false, false, 0); return; }
            WindowsNative.PassMouse(Handle, !Revealed || (!over && !busy));
            if (!Revealed) return;
            if (!rendering && NeedsRendering) StartRendering();
            if (cards.Count > 0 && Math.Abs(scrollMotion.Velocity) < 8 && Math.Abs(scrollMotion.Target - viewport.HorizontalOffset) < 0.5 && !busy && now >= nextGust)
            {
                nextGust = now.AddSeconds(7 + random.NextDouble() * 17);
                int direction = random.Next(2) == 0 ? -1 : 1;
                foreach (var card in cards.Values) card.Breeze(random.NextDouble() * 0.35, direction * (1.6 + random.NextDouble() * 1.8));
                StartRendering();
            }
            WindowsNative.Rectangle bounds;
            WindowsNative.GetWindowRect(Handle, out bounds);
            bool inside = cursor.X >= bounds.Left && cursor.X < bounds.Right && cursor.Y >= Display.Bounds.Top && cursor.Y < bounds.Bottom;
            if (inside) pinned = false;
            if (inside || pinned || busy || viewing || ChoosingAppearance || ChoosingBasket || ChoosingTexts || now < peekUntil) awaySince = DateTime.MaxValue;
            else
            {
                if (awaySince == DateTime.MaxValue) awaySince = now;
                if (now - awaySince > TimeSpan.FromMilliseconds(1200)) Reveal(false, false, 0);
            }
        }

        public void ShowCopied(string path) { if (cards.ContainsKey(path)) cards[path].FlashCopied(); }
        internal ShotCard CardFor(string path) { return cards[path]; }
        internal IEnumerable<ShotFlight> MotionWindows { get { return flights; } }
        internal IEnumerable<PinnedImageWindow> PinWindows { get { return pins.Values; } }
        internal bool Animating { get { return rendering; } }
    }

    internal sealed class ShotCard : Canvas, IDisposable
    {
        public readonly CaptureItem Item;
        public readonly Border Surface = new Border();
        internal readonly Button Grip = new Button();
        readonly TranslateTransform clipLift = new TranslateTransform();
        readonly ScaleTransform clipScale = new ScaleTransform(1, 1);
        readonly SpringMotion clipMotion = new SpringMotion(0.25, 0.8, 0);
        readonly ClothesClip clip = new ClothesClip();
        readonly Image photo = new Image();
        readonly Button close = new Button();
        readonly Border copied = new Border();
        readonly RotateTransform tilt = new RotateTransform(0, 82, 8);
        Point position;
        readonly ScaleTransform photoScale = new ScaleTransform(1, 1);
        readonly SpringMotion xMotion = new SpringMotion(0.55, 0.78, 0);
        readonly SpringMotion drop = new SpringMotion(0.42, 0.72, -46) { Target = 0 };
        readonly SpringMotion swing = new SpringMotion(2 * Math.PI / Math.Sqrt(46), 2.6 / (2 * Math.Sqrt(46)), 16) { Target = 0 };
        readonly SpringMotion scaleMotion = new SpringMotion(0.3, 0.6, 1);
        readonly DispatcherTimer hold = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(480) };
        readonly DispatcherTimer flash = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.2) };
        readonly Action<ShotAction, CaptureItem> act;
        readonly ImageMenu menu;
        internal ImageMenu ActionMenu { get { return menu; } }
        Point start;
        bool pressed, held, dragging, placed, hovering, gripHover;
        bool orderDrag;
        double orderX;
        internal Action<ShotCard, double> ReorderRequested;
        double entryTime, breezeDelay = -1, breezeAngle;
        ImageContent displayed;
        public bool Busy { get { return pressed || dragging || orderDrag || Releasing || menu.IsOpen; } }
        internal bool Animating
        {
            get
            {
                return !xMotion.Settled || !drop.Settled || !swing.Settled || !scaleMotion.Settled || !clipMotion.Settled
                    || breezeDelay >= 0 || entryTime < 0.16 || scaleMotion.Target != (pressed ? 0.95 : (hovering && !Releasing ? 1.035 : 1))
                    || clipMotion.Target != (gripHover || Releasing ? 1 : 0);
            }
        }
        public bool Flying { get; private set; }
        public bool Detached { get; set; }
        public bool Releasing { get; private set; }
        public bool IsDisposed { get; private set; }
        public readonly double Tilt;
        public LineTheme Appearance { get; private set; }
        public int ColorIndex { get; private set; }
        internal double MountX { get { return xMotion.Target; } }

        public ShotCard(CaptureItem item, Action<ShotAction, CaptureItem> act, Gallery gallery, Func<CaptureItem[]> hangingItems)
        {
            Item = item;
            Appearance = LineTheme.All[0];
            this.act = act;
            Width = 164;
            Height = 178;
            RenderTransform = tilt;
            Tilt = (item.Path.GetHashCode() & 7) * 0.7 - 2.45;
            Opacity = 0;
            Surface.RenderTransform = photoScale;
            Surface.RenderTransformOrigin = new Point(0.5, 0);
            Surface.Background = new SolidColorBrush(Color.FromArgb(245, 255, 255, 255));
            Surface.BorderBrush = new SolidColorBrush(Color.FromRgb(220, 225, 233));
            Surface.BorderThickness = new Thickness(1);
            Surface.CornerRadius = new CornerRadius(12);
            Surface.Effect = new DropShadowEffect { BlurRadius = 14, ShadowDepth = 4, Opacity = 0.2 };
            var imageLayer = new Grid();
            photo.Stretch = Stretch.Uniform;
            photo.Margin = new Thickness(6);
            imageLayer.Children.Add(photo);
            close.Content = LightTheme.CloseIcon();
            close.Style = LightTheme.ButtonStyle;
            close.MinWidth = 0;
            close.Width = close.Height = 22;
            close.Padding = new Thickness(0);
            close.Margin = new Thickness(3);
            close.HorizontalAlignment = HorizontalAlignment.Left;
            close.VerticalAlignment = VerticalAlignment.Top;
            close.Focusable = false;
            close.Opacity = 0;
            close.ToolTip = FileRules.IsInside(item.Path, gallery.Store.Inbox) ? "删除图片（移到回收站）" : "移除记录（保留原文件）";
            close.Click += delegate { act(ShotAction.Trash, item); };
            imageLayer.Children.Add(close);
            Surface.Child = imageLayer;
            Children.Add(Surface);
            var clipTransform = new TransformGroup();
            clipTransform.Children.Add(clipScale); clipTransform.Children.Add(clipLift);
            clip.RenderTransform = clipTransform;
            clip.RenderTransformOrigin = new Point(0.5, 0.5);
            clip.HorizontalAlignment = HorizontalAlignment.Center;
            clip.VerticalAlignment = VerticalAlignment.Top;
            clip.Margin = new Thickness(0, 4, 0, 0);
            Grip.Width = 28; Grip.Height = 34;
            Grip.Template = (ControlTemplate)System.Windows.Markup.XamlReader.Parse("<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'><Border Background='Transparent'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Top'/></Border></ControlTemplate>");
            Grip.Focusable = false;
            Grip.Cursor = Cursors.Hand;
            Grip.ToolTip = new ToolTip { Content = "贴到桌面", Style = LightTheme.HintStyle,
                Placement = System.Windows.Controls.Primitives.PlacementMode.Right, HorizontalOffset = 6 };
            ToolTipService.SetInitialShowDelay(Grip, 800);
            ToolTipService.SetBetweenShowDelay(Grip, 0);
            ToolTipService.SetShowDuration(Grip, 2500);
            System.Windows.Automation.AutomationProperties.SetName(Grip, "贴到桌面");
            Grip.Content = clip;
            Grip.MouseEnter += delegate { gripHover = true; };
            Grip.MouseLeave += delegate { gripHover = false; };
            Children.Add(Grip);
            SetLeft(Grip, 68); SetTop(Grip, -4);
            copied.Width = 84;
            copied.Padding = new Thickness(10, 4, 10, 4);
            copied.Background = Brushes.White;
            copied.BorderBrush = LightTheme.Brush("#DCE1E9");
            copied.BorderThickness = new Thickness(1);
            copied.CornerRadius = new CornerRadius(12);
            copied.Effect = new DropShadowEffect { BlurRadius = 8, ShadowDepth = 2, Opacity = 0.18 };
            copied.Child = new TextBlock { Text = "✓ 已复制", FontSize = 12, FontWeight = FontWeights.SemiBold,
                Foreground = LightTheme.Brush("#20408E"), TextAlignment = TextAlignment.Center };
            copied.Opacity = 0;
            copied.IsHitTestVisible = false;
            Children.Add(copied);
            flash.Tick += delegate { flash.Stop(); copied.BeginAnimation(OpacityProperty, new DoubleAnimation(0, TimeSpan.FromSeconds(0.2))); };
            Surface.MouseEnter += delegate { hovering = true; close.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.18))); };
            Surface.MouseLeave += delegate { hovering = false; close.BeginAnimation(OpacityProperty, new DoubleAnimation(0, TimeSpan.FromSeconds(0.18))); };
            Surface.MouseLeftButtonDown += Down;
            Surface.MouseLeftButtonUp += Up;
            Surface.MouseMove += Move;
            Surface.LostMouseCapture += delegate { hold.Stop(); pressed = false; };
            hold.Tick += delegate { hold.Stop(); held = true; pressed = false; Surface.ReleaseMouseCapture(); act(ShotAction.Edit, item); };
            menu = new ImageMenu(delegate(ShotAction action) { act(action, Item); }, FileRules.IsInside(item.Path, gallery.Store.Inbox));
            Surface.MouseRightButtonUp += delegate(object sender, MouseButtonEventArgs e)
            {
                e.Handled = true;
                var hanging = hangingItems();
                menu.SetBulk(Array.IndexOf(hanging, Item), hanging.Length);
                menu.PlacementTarget = Surface;
                WindowsNative.SetForegroundWindow(new WindowInteropHelper(Window.GetWindow(this)).Handle);
                menu.IsOpen = true;
            };
            UpdateImage();
        }

        public void ApplyTheme(LineTheme theme, int colorIndex)
        {
            Appearance = theme; ColorIndex = colorIndex;
            clip.Apply(theme, colorIndex);
        }

        public bool UpdateImage()
        {
            if (displayed == Item.Image) return false;
            displayed = Item.Image;
            menu.SetDetails(displayed.PixelWidth + " × " + displayed.PixelHeight);
            photo.Source = displayed.Thumbnail;
            double scale = Math.Min(142.0 / displayed.Thumbnail.PixelWidth, 98.0 / displayed.Thumbnail.PixelHeight);
            photo.Width = displayed.Thumbnail.PixelWidth * scale;
            photo.Height = displayed.Thumbnail.PixelHeight * scale;
            photo.Clip = new RectangleGeometry(new Rect(0, 0, photo.Width, photo.Height), 7, 7);
            Surface.Width = photo.Width + 14;
            Surface.Height = photo.Height + 14;
            SetLeft(Surface, (Width - Surface.Width) / 2);
            SetTop(Surface, 20);
            SetLeft(copied, (Width - copied.Width) / 2);
            SetTop(copied, Surface.Height + 30);
            return true;
        }

        public void Place(double x, bool immediately)
        {
            if (!placed || immediately) xMotion.Snap(x);
            else xMotion.Target = x;
            placed = true;
        }

        public void Frame(double elapsed, double sag, double lineWidth, double scrollOffset)
        {
            if (IsDisposed) return;
            xMotion.Step(elapsed);
            drop.Step(elapsed);
            swing.Step(elapsed);
            if (breezeDelay >= 0)
            {
                breezeDelay -= elapsed;
                if (breezeDelay < 0 && !Flying && !Busy) Nudge(breezeAngle);
            }
            scaleMotion.Target = pressed ? 0.95 : (hovering && !Releasing ? 1.035 : 1);
            scaleMotion.Step(elapsed);
            clipMotion.Target = gripHover || Releasing ? 1 : 0;
            clipMotion.Step(elapsed);
            clipLift.Y = -0.8 * clipMotion.Position;
            clipScale.ScaleX = clipScale.ScaleY = 1 + 0.06 * clipMotion.Position;
            photoScale.ScaleX = photoScale.ScaleY = scaleMotion.Position;
            double fraction = Math.Max(0, Math.Min(1, (xMotion.Position + 82 - scrollOffset) / lineWidth));
            position.X = orderDrag ? orderX : xMotion.Position;
            position.Y = 18 + 4 * sag * fraction * (1 - fraction) - 8 + drop.Position;
            Canvas.SetLeft(this, position.X);
            Canvas.SetTop(this, position.Y);
            tilt.Angle = Tilt + swing.Position;
            entryTime += elapsed;
            Opacity = Flying ? 0 : Math.Min(1, entryTime / 0.16);
        }

        public void Breeze(double delay, double degrees) { breezeDelay = delay; breezeAngle = degrees; }
        public void ScrollWith(double velocity) { swing.Target = Flying || Busy ? 0 : Math.Max(-2.5, Math.Min(2.5, -velocity / 200)); }
        public void Nudge(double degrees) { if (!Flying && !IsDisposed) swing.Velocity += degrees * 8; }

        public void OpenClip()
        {
            ((ToolTip)Grip.ToolTip).IsOpen = false;
            ToolTipService.SetIsEnabled(Grip, false);
            Releasing = true; Grip.IsEnabled = false;
            clip.Open();
        }
        public void DetachPhoto()
        {
            Releasing = false; Detached = true;
            Surface.Opacity = 0;
            BeginAnimation(OpacityProperty, new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.12)) { BeginTime = TimeSpan.FromSeconds(0.10) });
        }
        public void ResetClip()
        {
            BeginAnimation(OpacityProperty, null);
            Surface.Opacity = 1;
            ToolTipService.SetIsEnabled(Grip, true);
            Releasing = false; Grip.IsEnabled = true;
            clip.Reset();
        }

        public void BeginFlight()
        {
            Releasing = false;
            Flying = true;
            drop.Snap(0);
            swing.Snap(0);
            entryTime = 0;
            Opacity = 0;
        }

        public void Land()
        {
            if (IsDisposed) return;
            Flying = false;
            entryTime = 0;
            Nudge(2.2);
        }

        public Rect PhotoRect()
        {
            var parent = (Canvas)Parent;
            double x = position.X + (Width - Surface.Width) / 2, y = position.Y + 20;
            return new Rect(parent.PointToScreen(new Point(x, y)), parent.PointToScreen(new Point(x + Surface.Width, y + Surface.Height)));
        }

        void Down(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            if (e.ClickCount == 2) { hold.Stop(); held = true; act(ShotAction.Open, Item); return; }
            start = e.GetPosition(this);
            pressed = true;
            held = false;
            Surface.CaptureMouse();
            hold.Start();
        }

        void Up(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            hold.Stop();
            if (orderDrag)
            {
                orderDrag = false;
                Surface.Opacity = 1;
                pressed = false;
                Surface.ReleaseMouseCapture();
                if (ReorderRequested != null) ReorderRequested(this, orderX);
                return;
            }
            bool copy = pressed && !held && !dragging;
            pressed = false;
            Surface.ReleaseMouseCapture();
            if (copy) act(ShotAction.Copy, Item);
        }

        void Move(object sender, MouseEventArgs e)
        {
            if (!pressed || held || dragging || e.LeftButton != MouseButtonState.Pressed) return;
            Point position = e.GetPosition(this);
            double dx = position.X - start.X, dy = position.Y - start.Y;
            // 在绳子上做水平拖动 = 换位置；垂直幅度大或拖出绳子时才当作拖到其他应用。
            if (!orderDrag && Math.Abs(dx) > 36 && Math.Abs(dy) < 34)
            {
                hold.Stop();
                orderDrag = true;
                Surface.Opacity = 0.88;
                Surface.CaptureMouse();
            }
            if (orderDrag)
            {
                orderX = MountX + dx;
                Canvas.SetLeft(this, orderX);
                return;
            }
            if (Math.Abs(dx) < SystemParameters.MinimumHorizontalDragDistance && Math.Abs(dy) < SystemParameters.MinimumVerticalDragDistance) return;
            hold.Stop();
            pressed = false;
            dragging = true;
            Surface.Opacity = 0.45;
            Surface.ReleaseMouseCapture();
            var payload = new DataObject(DataFormats.FileDrop, new[] { Item.Path });
            var preview = new DragPreview(Item.Image.Thumbnail);
            try { preview.Show(); DragDrop.DoDragDrop(Surface, payload, DragDropEffects.Copy | DragDropEffects.Move); }
            finally { preview.Close(); dragging = false; Surface.Opacity = 1; }
        }

        public void FlashCopied()
        {
            copied.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.15)));
            Nudge(3);
            flash.Stop(); flash.Start();
        }
        public void Dispose() { IsDisposed = true; hold.Stop(); flash.Stop(); menu.IsOpen = false; }
    }

    internal sealed class DragPreview : Window
    {
        readonly DispatcherTimer follow = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(25) };
        IntPtr handle;

        public DragPreview(System.Windows.Media.Imaging.BitmapSource image)
        {
            double scale = Math.Min(126.0 / image.PixelWidth, 86.0 / image.PixelHeight);
            Width = image.PixelWidth * scale + 12;
            Height = image.PixelHeight * scale + 12;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ShowActivated = false;
            ShowInTaskbar = false;
            Topmost = true;
            IsHitTestVisible = false;
            Opacity = 0.8;
            Content = new Border { CornerRadius = new CornerRadius(10), Background = Brushes.White, Padding = new Thickness(6), Child = new Image { Source = image } };
            SourceInitialized += delegate
            {
                handle = new WindowInteropHelper(this).Handle;
                WindowsNative.PrepareOverlay(handle);
                WindowsNative.PassMouse(handle, true);
                Follow();
                follow.Start();
            };
            follow.Tick += delegate { Follow(); };
            Closed += delegate { follow.Stop(); };
        }

        void Follow()
        {
            var cursor = WindowsNative.Cursor();
            double scale = WindowsNative.MonitorScale(WindowsNative.ScreenAtPointer());
            WindowsNative.SetWindowPos(handle, new IntPtr(-1), cursor.X + 18, cursor.Y + 20, (int)(Width * scale), (int)(Height * scale), 0x10);
        }
    }

    internal sealed class SimpleRopeCard : Canvas, IDisposable
    {
        public enum RopeKind { File, Text }
        public string Key { get; private set; }
        public RopeKind Kind { get; private set; }
        public string Payload { get; private set; }
        public bool Animating { get { return entryTime < 0.2; } }
        readonly Border surface = new Border();
        readonly Button close = new Button();
        readonly Border copied = new Border();
        readonly DispatcherTimer flash = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.2) };
        readonly RotateTransform tilt;
        readonly Action<string> removeRequested;
        double entryTime;
        double x;

        public SimpleRopeCard(string key, string payload, RopeKind kind, Action<string> remove)
        {
            Key = key; Payload = payload; Kind = kind; removeRequested = remove;
            Width = 164; Height = 178; Opacity = 0;
            tilt = new RotateTransform((key.GetHashCode() & 7) * 0.7 - 2.45, 82, 8);
            RenderTransform = tilt;
            surface.Background = new SolidColorBrush(Color.FromArgb(245, 255, 255, 255));
            surface.BorderBrush = new SolidColorBrush(Color.FromRgb(220, 225, 233));
            surface.BorderThickness = new Thickness(1);
            surface.CornerRadius = new CornerRadius(12);
            surface.Effect = new DropShadowEffect { BlurRadius = 14, ShadowDepth = 4, Opacity = 0.2 };
            surface.Width = 156; surface.Height = 130; surface.Cursor = Cursors.Hand;
            var layer = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, MaxWidth = 136, Margin = new Thickness(8) };
            if (kind == RopeKind.File) BuildFileBody(layer); else BuildTextBody(layer);
            close.Content = LightTheme.CloseIcon();
            close.Style = LightTheme.ButtonStyle;
            close.MinWidth = 0; close.Width = close.Height = 22; close.Padding = new Thickness(0);
            close.Margin = new Thickness(3); close.HorizontalAlignment = HorizontalAlignment.Left; close.VerticalAlignment = VerticalAlignment.Top;
            close.Focusable = false; close.Opacity = 0; close.ToolTip = "取下";
            close.Click += delegate { if (removeRequested != null) removeRequested(Key); };
            var overlay = new Grid();
            overlay.Children.Add(layer); overlay.Children.Add(close);
            surface.Child = overlay;
            SetLeft(surface, 4); SetTop(surface, 20);
            Children.Add(surface);
            var clip = new ClothesClip();
            clip.Apply(LineTheme.All[0], 0);
            clip.HorizontalAlignment = HorizontalAlignment.Center; clip.VerticalAlignment = VerticalAlignment.Top;
            clip.Margin = new Thickness(0, 4, 0, 0);
            var grip = new Button { Width = 28, Height = 34, Focusable = false, Cursor = Cursors.Hand, Content = clip, IsHitTestVisible = false };
            grip.Template = (ControlTemplate)System.Windows.Markup.XamlReader.Parse("<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'><Border Background='Transparent'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Top'/></Border></ControlTemplate>");
            Children.Add(grip); SetLeft(grip, 68); SetTop(grip, -4);
            copied.Width = 84; copied.Padding = new Thickness(10, 4, 10, 4);
            copied.Background = Brushes.White; copied.BorderBrush = LightTheme.Brush("#DCE1E9");
            copied.BorderThickness = new Thickness(1); copied.CornerRadius = new CornerRadius(12);
            copied.Effect = new DropShadowEffect { BlurRadius = 8, ShadowDepth = 2, Opacity = 0.18 };
            copied.Child = new TextBlock { Text = "✓ 已复制", FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = LightTheme.Brush("#20408E"), TextAlignment = TextAlignment.Center };
            copied.Opacity = 0; copied.IsHitTestVisible = false;
            Children.Add(copied); SetLeft(copied, 40); SetTop(copied, 160);
            flash.Tick += delegate { flash.Stop(); copied.BeginAnimation(OpacityProperty, new DoubleAnimation(0, TimeSpan.FromSeconds(0.2))); };
            surface.MouseEnter += delegate { close.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.18))); };
            surface.MouseLeave += delegate { close.BeginAnimation(OpacityProperty, new DoubleAnimation(0, TimeSpan.FromSeconds(0.18))); };
            surface.MouseLeftButtonUp += delegate { CopyPayload(); };
            surface.MouseRightButtonUp += delegate(object sender, MouseButtonEventArgs e)
            {
                e.Handled = true;
                var menu = new ContextMenu();
                if (Kind == RopeKind.File)
                {
                    var open = new MenuItem { Header = "打开" };
                    open.Click += delegate { try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(Payload) { UseShellExecute = true }); } catch { } };
                    menu.Items.Add(open);
                }
                var copy = new MenuItem { Header = Kind == RopeKind.File ? "复制文件" : "复制全文" };
                copy.Click += delegate { CopyPayload(); };
                menu.Items.Add(copy);
                var detach = new MenuItem { Header = "取下" };
                detach.Click += delegate { if (removeRequested != null) removeRequested(Key); };
                menu.Items.Add(detach);
                var window = Window.GetWindow(this);
                if (window != null) WindowsNative.SetForegroundWindow(new WindowInteropHelper(window).Handle);
                menu.PlacementTarget = surface; menu.IsOpen = true;
            };
        }

        void BuildFileBody(StackPanel layer)
        {
            var icon = new Image { Width = 44, Height = 44, Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 8) };
            try
            {
                using (var extracted = System.Drawing.Icon.ExtractAssociatedIcon(Payload))
                using (var bitmap = extracted.ToBitmap())
                {
                    var source = System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(bitmap.GetHicon(), Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                    source.Freeze(); icon.Source = source;
                }
            }
            catch { }
            layer.Children.Add(icon);
            string name = System.IO.Path.GetFileName(Payload);
            layer.Children.Add(new TextBlock { Text = name, FontSize = 12, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, MaxHeight = 32, TextAlignment = TextAlignment.Center, Foreground = Brushes.Black, TextTrimming = TextTrimming.CharacterEllipsis, ToolTip = name });
            string size;
            try { long bytes = new System.IO.FileInfo(Payload).Length; size = bytes >= 1048576 ? (bytes / 1048576.0).ToString("0.#") + " MB" : Math.Max(1, bytes / 1024) + " KB"; }
            catch { size = ""; }
            layer.Children.Add(new TextBlock { Text = size, FontSize = 11, Foreground = LightTheme.Brush("#65717F"), TextAlignment = TextAlignment.Center, Margin = new Thickness(0, 4, 0, 0) });
        }

        void BuildTextBody(StackPanel layer)
        {
            layer.Children.Add(new TextBlock { Text = "❝", FontSize = 22, Foreground = LightTheme.Brush("#B8C2CF"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 2) });
            string summary = Payload.Length > 96 ? Payload.Substring(0, 96) + "…" : Payload;
            layer.Children.Add(new TextBlock { Text = summary, FontSize = 12.5, TextWrapping = TextWrapping.Wrap, MaxHeight = 84, Foreground = new SolidColorBrush(Color.FromRgb(40, 48, 58)), TextTrimming = TextTrimming.CharacterEllipsis, ToolTip = "单击复制全文" });
            layer.Children.Add(new TextBlock { Text = "文字 · 单击复制全文", FontSize = 11, Foreground = LightTheme.Brush("#65717F"), Margin = new Thickness(0, 6, 0, 0) });
        }

        void CopyPayload()
        {
            try
            {
                if (Kind == RopeKind.File)
                {
                    var list = new System.Collections.Specialized.StringCollection { Payload };
                    Clipboard.SetFileDropList(list);
                }
                else Clipboard.SetText(Payload);
                copied.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.12)));
                flash.Stop(); flash.Start();
            }
            catch { }
        }

        public void Place(double newX, bool immediately)
        {
            x = newX;
            Canvas.SetLeft(this, x);
        }

        public void Frame(double elapsed, double sag, double lineWidth, double scrollOffset)
        {
            entryTime += elapsed;
            Opacity = Math.Min(1, entryTime / 0.16);
            double fraction = Math.Max(0, Math.Min(1, (x + 82 - scrollOffset) / lineWidth));
            SetTop(this, 18 + 4 * sag * fraction * (1 - fraction) - 8);
        }

        public void Dispose() { flash.Stop(); }
    }
}
