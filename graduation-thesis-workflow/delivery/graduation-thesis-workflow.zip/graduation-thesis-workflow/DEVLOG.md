# 开发记录

## 2026-09-10 · v0.1.0 初始搭建

根据使用者确认：公开可复用、覆盖各专业入口、按学校确定交付物、确认需求后自动推进、绝不编造文献与研究材料。

完成一个自包含技能、七个阶段模块、五类方法分支、证据与状态协议、公开来源目录；实现初始化/检查/哈希、Crossref 查询与三个平台 ZIP 打包脚本。补充安装、发布、许可与维护文档。

采用官方技能结构说明并使用标准库，不复制来源或许可证未核实的外部技能。已有 humanizer 可以在用户环境可用时选用，但不参与真实性判定。

第一轮 14 项离线测试通过。Crossref 实际联网检索成功返回 2 条元数据候选；未读取全文。源技能静态验证通过，Windows 下需用 -X utf8 运行上游验证器。

最终 18 项回归全部通过，新增网络失败无伪造输出、检索不升级为全文、已有检索文件不覆盖、技能内链接完整性检查。三种 ZIP 已生成并附 SHA256 清单；Codex 与 Claude Code 包内容相同，WorkBuddy 包增加专用元数据。未执行原生客户端端到端论文验证或 GitHub 发布。

## 2026-09-10 · v0.2.0 新手安装与自动润色

新增一句话安装入口、无 Git/Python 的 Windows 技能安装器、官方 Python 与文档依赖自动配置；内置经 MIT 许可核验的 Humanizer 3.0.0，在最终交付前执行并复核。保留权限与真实材料边界。PowerShell 5.1 参数引号问题已通过实际测试修复。

最终 26 项测试通过，源技能格式有效。上游固定提交为 9862685f575c65a8247f90369951df1b3416e3d6。官方 Python AMD64 安装器真实 HEAD 返回 200；未在干净机器执行安装器或验证全部文档软件，具体范围见 docs/VALIDATION.md。

## 2026-09-10 · 0.3.0

参考上游调研，独立实现审查快照与润色 token 比较；补充文献原文定位、会计分支及三端能力回退说明。新增防止改稿后复用审查的回归测试。分发仍由单一技能源生成，不增加核心依赖。实际测试结果见 docs/VALIDATION.md。

## 2026-10-03 Windows CI 回归

新增仓库 CI 实际运行后发现：Windows 捕获 stdout 使用传统代码页导致中文路径初始化虽创建文件却报编码失败；Git 自动换行转换改变 Humanizer 原始文件哈希。项目 CLI 现在明确 UTF-8 输出并增加 cp1252 回归，仓库属性保留技能包原始字节。同步重建三个分发 ZIP；没有修改上游 Humanizer 内容。CI 结果见仓库清理报告。

## 2026-10-24 · Humanizer 上游更新

内置 Humanizer 更新至 3.1.0，固定提交 8c307f367c91bd974002f10f2be2965d642c13df；保留原始 SKILL.md 与 MIT 许可，重建三个平台包。

## 2026-11-03 · 0.4.0 Pi 客户端与 Humanizer-zh

内置润色工具由英文版 blader/humanizer 3.1.0 全量替换为 Humanizer-zh（op7418/Humanizer-zh，MIT，固定提交 f4518a8eab97b8bfebc66a89d34320a89bef6930，本地副本逐字节对照）；SKILL.md 与 LICENSE 按上游字节保存，UPSTREAM.json 记录哈希。08 模块重写，明确中文润色定位与外文稿件边界；polishing.json 新项目写入 tool=humanizer-zh，audit 同时接受旧值 humanizer，schema_version 保持 1。

新增 Pi 为第四个分发客户端：package.py 生成 graduation-thesis-pi.zip（与 Codex 包同内容）；install.ps1 支持 -Client pi，目标 ~/.pi/agent/skills/graduation-thesis/，只复制文件不改动客户端配置；settings.json 注册步骤写入安装文档，由助手在用户授权下执行。分发 ZIP 从三个增加到四个。
