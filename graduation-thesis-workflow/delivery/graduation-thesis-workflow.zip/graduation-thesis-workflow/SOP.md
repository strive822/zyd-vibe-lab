# 维护流程

1. 修改唯一技能源；阶段逻辑变化时检查对缺材料、证据范围和恢复行为的影响。
2. 脚本变更运行 `python -m unittest discover -s tests -v`。测试使用临时目录，不接触用户论文。
3. 可使用 skill-creator 的 quick_validate 检查源 SKILL.md；它不是研究行为验证。
4. 涉及检索时，用公开查询做一次真实联网检查，结果只放 `.test-output/`；网络故障不能记录为通过。
5. 运行 `python scripts/package.py`，检查三个 ZIP 和哈希。
6. 更新 DEVLOG、GOTCHAS、DECISIONS 与 docs/VALIDATION。发布按 docs/RELEASE.md。

开始真实论文：读完整入口，初始化独立私有目录，确认需求，再按状态推进。检查器报错先查实际产物，不为通过测试修改真假判定或删掉需求。

新增安装器测试需在允许执行 PowerShell 的正常用户权限下运行，不修改系统执行策略。技能、脚本或 vendor 变更后重建 packages，保留第三方许可。polishing.json 缺失的旧论文项目应先创建 pending 记录并实际执行润色，不回填虚假完成状态。

## 0.3.0 发布顺序

修改单一技能源 → `python -m unittest discover -s tests -v` → `python scripts/package.py --out packages` → 核对三端 ZIP、许可、校验和与本地链接 → 同步并只提交本项目文件。论文交付先实质审查再 review-snapshot，最后 audit；不能通过重写快照掩盖未检查的修改。

## 2026-10-24 · Humanizer 上游更新

更新 vendor 后核验 UPSTREAM.json 和原始文件字节，运行流程测试并在允许脚本执行的 Windows CI 验证安装器，再重建 packages 和独立 delivery。

## 2026-11-03 · 0.4.0

四个客户端的安装验证统一用 -Plan 与临时 -SkillsDir，不在维护者本机注册技能。更新 Humanizer-zh 时从上游拉取固定提交，与本地副本逐字节对照后更新 UPSTREAM.json 哈希，再重建 packages 和 delivery。
